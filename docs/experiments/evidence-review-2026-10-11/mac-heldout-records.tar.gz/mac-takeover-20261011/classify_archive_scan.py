"""Classify redacted scanner findings as exact frozen source hashes, or unknown.

No scanner bypass, allowlist, normalization or Git-history change is performed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path, PurePosixPath

REPO = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
DOCS = REPO / 'docs/experiments/evidence-review-2026-10-11'

parser = argparse.ArgumentParser()
parser.add_argument('--scan', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise SystemExit('Do not overwrite a completed scan classification')
findings = json.loads(args.scan.read_text())
records = []
for finding in findings:
    row = {key: finding.get(key) for key in ('RuleID', 'File', 'StartLine', 'EndLine', 'Fingerprint')}
    row.update(runtime_source_field=False, source_hash_verified_at_recorded_revision=False)
    try:
        archive_path, member = finding['File'].split('!')
        archive_path = Path(archive_path)
        parts = PurePosixPath(member)
        if archive_path.parent != DOCS or parts.is_absolute() or '..' in parts.parts:
            raise ValueError('Unexpected scanner member path')
        with tarfile.open(archive_path) as tar:
            raw = tar.extractfile(member).read()
        protocol = json.loads(raw)
        line = raw.decode().splitlines()[finding['StartLine'] - 1]
        match = re.fullmatch(r'\s*"([^"\n]+)":\s*"([a-f0-9]{64})",?\s*', line)
        if finding['RuleID'] == 'generic-api-key' and finding['StartLine'] == finding['EndLine'] and match:
            source, value = match.groups()
            row['runtime_source_field'] = protocol.get('runtime_source_sha256', {}).get(source) == value
            revision = protocol.get('git_revision')
            if row['runtime_source_field'] and isinstance(revision, str) and re.fullmatch(r'[a-f0-9]{40}', revision):
                source_bytes = subprocess.check_output(['git', 'show', f'{revision}:{source}'], cwd=REPO, stderr=subprocess.DEVNULL)
                row['source_hash_verified_at_recorded_revision'] = hashlib.sha256(source_bytes).hexdigest() == value
                row.update(source_path=source, frozen_revision=revision)
    except (ValueError, KeyError, TypeError, IndexError, subprocess.CalledProcessError):
        row['classification'] = 'unresolved'
    row['classification'] = 'verified_source_sha256' if row['runtime_source_field'] and row['source_hash_verified_at_recorded_revision'] else 'unresolved'
    records.append(row)
result = {'scan_sha256': hashlib.sha256(args.scan.read_bytes()).hexdigest(), 'raw_scanner_exit_code': 1 if findings else 0,
    'findings': len(records), 'verified_source_hash_findings': sum(row['classification'] == 'verified_source_sha256' for row in records),
    'unresolved': [row for row in records if row['classification'] != 'verified_source_sha256'], 'records': records,
    'scanner_configuration_changed': False,
    'interpretation': 'Every resolved finding is the exact SHA-256 of its named source file at the protocol-recorded revision, not credential material. Scanner exit/findings remain unchanged; unresolved entries block release.'}
with args.output.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))
raise SystemExit(1 if result['unresolved'] else 0)
