"""Read-only live status; never display model reasoning, text or credentials."""
from __future__ import annotations

import collections
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML/rfc-heldout-scoped-v3')

def rows(path: Path) -> list[dict]:
    if not path.exists():
        return []
    values = []
    with path.open() as stream:
        for number, line in enumerate(stream, 1):
            if not line.endswith('\n'):
                continue  # An in-progress append, not a completed durable record.
            try:
                values.append(json.loads(line))
            except ValueError:
                raise ValueError(f'Invalid completed record: {path.name}:{number}') from None
    return values

reports = []
all_trials = []
for shard in range(3):
    directory = ROOT / f'shard-{shard}'
    trials = rows(directory / 'trials.jsonl')
    starts = rows(directory / 'started.jsonl')
    events = rows(directory / 'provider-events.jsonl')
    final_ids = {trial['id'] for trial in trials}
    latest = {event['call_id']: event for event in events}
    all_trials.extend(trials)
    reports.append({'shard': shard, 'completed': len(trials), 'planned': 48,
        'active_trials': [start['id'] for start in starts if start['id'] not in final_ids],
        'calls_started': len(latest),
        'calls_returned': sum(event.get('status') == 'response' for event in latest.values()),
        'calls_without_return_for_finalized_trials': sum(event.get('status') == 'no_response' and event.get('trial_id') in final_ids for event in latest.values()),
        'pending_calls': [{key: event.get(key) for key in ('trial_id', 'kind', 'started_at')}
                          for event in latest.values() if event.get('status') == 'no_response' and event.get('trial_id') not in final_ids],
        'last_provider_event_at': events[-1].get('ended_at', events[-1].get('started_at')) if events else None})
arms = {}
for arm in ('baseline', 'review'):
    selected = [trial for trial in all_trials if trial['arm'] == arm]
    arms[arm] = {'completed': len(selected),
        'delivery_errors': sum(bool(trial.get('error')) for trial in selected),
        'stops': dict(collections.Counter((trial.get('response') or {}).get('stop_reason') for trial in selected)),
        'review_states': dict(collections.Counter((trial.get('response') or {}).get('evidence_review', {}).get('status') for trial in selected)),
        'observed_tokens': sum(trial.get('provider_usage', {}).get('observed_tokens', {}).get('total_tokens', 0) for trial in selected),
        'incomplete_usage_episodes': sum(not trial.get('provider_usage', {}).get('usage_complete') for trial in selected)}
result = {'observed_at': datetime.now(timezone.utc).isoformat(),
    'completed': len(all_trials), 'planned': 144, 'shards': reports, 'arms': arms,
    'gate_failures': [trial['id'] for trial in all_trials if not all(trial.get('gates', {}).values())],
    'failures': [{'id': trial['id'], 'error': trial['error']} for trial in all_trials if trial.get('error')]}
if '--compact' in sys.argv:
    result = {'observed_at': result['observed_at'], 'completed': result['completed'], 'planned': 144,
        'shards': [{key: row[key] for key in ('shard', 'completed', 'active_trials', 'calls_started', 'calls_returned')} for row in reports],
        'arms': arms, 'gate_failures': result['gate_failures'], 'delivery_errors': len(result['failures'])}
print(json.dumps(result, ensure_ascii=False, indent=None if '--compact' in sys.argv else 2))
