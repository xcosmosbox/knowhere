"""Offline structural audit, independent of production verdict parsing.

Reads only recorded evidence/metadata and frozen source. It does not call a model,
resend a trial, change verdicts, or infer semantic entailment from an exact quote.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
sys.path.insert(0, str(ROOT / 'scripts/evidence_review_benchmark'))
sys.path.insert(0, str(ROOT / 'packages/shared-python'))
from corpus import prepare_corpus

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def digest(data) -> str:
    return sha(json.dumps(data, sort_keys=True, ensure_ascii=False).encode())

def rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []

def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate_json_key')
        result[key] = value
    return result

def parse_independent(call: dict) -> dict:
    outputs = call.get('review_output', [])
    if call.get('http_status') != 200 or call.get('finish_reasons') != ['stop'] or len(outputs) != 1:
        raise ValueError('incomplete_review_response')
    raw = json.loads(outputs[0], object_pairs_hook=no_duplicates)
    if not isinstance(raw, dict) or set(raw) != {'status', 'reason', 'coverage'}:
        raise ValueError('assessment_schema')
    if raw['status'] not in ('sufficient', 'insufficient', 'unverified'):
        raise ValueError('assessment_status')
    if not isinstance(raw['reason'], str) or not raw['reason'].strip() or len(raw['reason']) > 400:
        raise ValueError('reason_contract')
    if not isinstance(raw['coverage'], list) or not 1 <= len(raw['coverage']) <= 24:
        raise ValueError('coverage_contract')
    evidence = {item['evidence_id']: item for item in call['review_input']['evidence']}
    if len(evidence) != len(call['review_input']['evidence']):
        raise ValueError('duplicate_evidence_id')
    facets = {}
    for facet in raw['coverage']:
        if not isinstance(facet, dict) or set(facet) != {'facet_id', 'requirement', 'status', 'citations'}:
            raise ValueError('facet_schema')
        identity = facet['facet_id']
        if (not isinstance(identity, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', identity)
                or identity in facets or not isinstance(facet['requirement'], str)
                or not facet['requirement'].strip() or len(facet['requirement']) > 2000):
            raise ValueError('facet_identity_or_requirement')
        if facet['status'] not in ('supported', 'missing', 'conflicting'):
            raise ValueError('facet_status')
        citations = facet['citations']
        if not isinstance(citations, list) or len(citations) > 8:
            raise ValueError('citation_count')
        if facet['status'] in ('supported', 'conflicting') and not citations:
            raise ValueError('uncited_claim')
        resolved = []
        for citation in citations:
            if not isinstance(citation, dict) or set(citation) not in (
                    {'evidence_id', 'quote'}, {'evidence_id', 'start_span', 'end_span'}):
                raise ValueError('citation_schema')
            identity = citation['evidence_id']
            if not isinstance(identity, str) or identity not in evidence:
                raise ValueError('citation_unknown_evidence')
            spans = evidence[identity]['citation_spans']
            text = ''.join(span['text'] for span in spans)
            if 'quote' in citation:
                quote = citation['quote']
            else:
                positions = {span['span_id']: index for index, span in enumerate(spans)}
                first, last = citation['start_span'], citation['end_span']
                if (not isinstance(first, str) or not isinstance(last, str)
                        or first not in positions or last not in positions or positions[first] > positions[last]):
                    raise ValueError('citation_range')
                quote = ''.join(span['text'] for span in spans[positions[first]:positions[last] + 1])
            if not isinstance(quote, str) or not quote.strip() or quote not in text:
                raise ValueError('citation_not_exact')
            resolved.append({'evidence_id': identity, 'quote': quote})
        facets[facet['facet_id']] = {**facet, 'citations': resolved}
    frozen = call['review_input'].get('frozen_requirements')
    coverage = list(facets.values())
    if frozen:
        if {(key, row['requirement']) for key, row in facets.items()} != {(row['facet_id'], row['requirement']) for row in frozen}:
            raise ValueError('frozen_requirements_changed')
        coverage = [facets[row['facet_id']] for row in frozen]
    all_supported = all(row['status'] == 'supported' for row in coverage)
    if raw['status'] == 'sufficient' and not all_supported or raw['status'] == 'insufficient' and all_supported:
        raise ValueError('inconsistent_verdict')
    return {**raw, 'coverage': coverage}

def audit(args) -> dict:
    protocol = json.loads((args.experiment / 'protocol.json').read_text())
    gold_path = ROOT / 'scripts/fixtures/evidence_review_rfc_20261011/gold.json'
    gold = json.loads(gold_path.read_text())
    manifest = prepare_corpus(ROOT, gold_path)
    questions = {row['id']: row for row in gold['questions']}
    expected = {f'{row["question_id"]}:{row["repeat"]}:{arm}' for row in protocol['schedule']
                if row['split'] == args.split for arm in row['order']}
    paths = sorted(args.experiment.glob('shard-*/trials.jsonl')) if args.split == 'held_out' else [args.experiment / 'development/trials.jsonl']
    trials = [row for path in paths for row in rows(path)]
    starts = [row for path in paths for row in rows(path.with_name('started.jsonl'))]
    errors = []
    def check(value, identity, rule):
        if not value:
            errors.append({'identity': identity, 'rule': rule})
    identities = [row['id'] for row in trials]
    check(len(set(identities)) == len(identities), 'run', 'no_duplicate_trial_ids')
    check(set(identities) == expected, 'run', 'complete_frozen_denominator')
    check(len(starts) == len(expected) and {row['id'] for row in starts} == expected, 'run', 'one_start_per_scheduled_trial')
    check(sha(gold_path.read_bytes()) == protocol['gold_sha256'], 'run', 'frozen_gold_hash')
    check(manifest['corpus_digest'] == protocol['corpus_digest'], 'run', 'frozen_corpus_digest')
    source_checks = None
    if args.current_sources:
        source_checks = {path: sha((ROOT / path).read_bytes()) == value for path, value in protocol['runtime_source_sha256'].items()}
        check(all(source_checks.values()), 'run', 'frozen_runtime_source_hashes')
    call_counts = collections.Counter()
    validity = collections.Counter()
    unverified = collections.Counter()
    unknown_scope_history = []
    records = []
    all_calls = []
    for trial in trials:
        identity = trial['id']
        question = questions[trial['question_id']]
        check(trial['protocol_digest'] == digest(protocol), identity, 'trial_protocol_digest')
        check(all(trial['gates'].values()), identity, 'recorded_runtime_gates')
        source_units = {(doc['document_id'], chunk['chunk_id']): chunk['content']
                        for doc in manifest['documents'] if doc['doc_key'] in question['doc_keys']
                        for chunk in doc['chunks'] if chunk['type'] == 'text'}
        scope = trial.get('episode', {}).get('source_scope_accounting')
        if protocol['resources'].get('closed_source_scope_feedback'):
            if not isinstance(scope, dict) and trial.get('error'):
                unknown_scope_history.append(identity)
            else:
                check(isinstance(scope, dict), identity, 'scope_present')
            if isinstance(scope, dict):
                receipts = scope.get('read_units', [])
                keys = [(row.get('document_id'), row.get('chunk_id')) for row in receipts]
                check(len(keys) == len(set(keys)) == scope.get('exact_full_reads'), identity, 'unique_receipt_count')
                check(scope.get('source_units') == len(source_units), identity, 'complete_allowed_inventory_count')
                check(scope.get('all_scoped_text_read') is (set(keys) == source_units.keys()), identity, 'read_completeness_not_fabricated')
                observations = [row['observation_text'] for row in trial.get('episode', {}).get('steps', []) if row['tool_name'] == 'corpus.read' and not row.get('error')]
                for receipt, key in zip(receipts, keys):
                    check(key in source_units and receipt.get('content_sha256') == sha(source_units.get(key, '').encode()), identity, 'receipt_source_hash')
                    # Failed episodes do not retain a completed tool-step list. They
                    # remain explicitly weaker evidence, not a false audit success.
                    if not trial.get('error'):
                        check(key in source_units and any(source_units[key] in text for text in observations), identity, 'receipt_full_content_in_real_read_observation')
        calls = trial.get('provider_calls', [])
        all_calls.extend(calls)
        parsed_reviews = []
        for call in calls:
            call_counts[call['kind']] += 1
            check(call.get('requested_model') == 'deepseek-flash', identity, 'requested_model')
            check(call.get('max_tokens') == 393216 and call.get('thinking') == {'type': 'enabled'} and call.get('reasoning_effort') == 'max', identity, 'provider_max_thinking')
            timeout = call.get('transport_timeout')
            check(isinstance(timeout, dict) and all(value is None for value in timeout.values()), identity, 'no_transport_deadline')
            check(call.get('temperature') is None, identity, 'no_ignored_thinking_temperature')
            if call.get('returned_model') is not None:
                check(call.get('returned_model') == 'deepseek-flash', identity, 'returned_model')
            if call['kind'] == 'reviewer':
                received = call.get('review_input', {})
                check(received.get('original_query') == question['query'], identity, 'original_reviewer_query')
                for item in received.get('evidence', []):
                    text = ''.join(span['text'] for span in item['citation_spans'])
                    # Compare source metadata and lossless text against an actual
                    # recorded snapshot, not against a candidate summary or gold.
                    received_item = {key: value for key, value in item.items() if key != 'citation_spans'}
                    matches = [row for snapshot in trial.get('snapshots', []) for row in snapshot['items']
                               if row == {**received_item, 'text': text}]
                    check(bool(matches), identity, 'lossless_review_input_matches_recorded_snapshot')
                try:
                    parsed = parse_independent(call)
                    validity['valid'] += 1
                    parsed_reviews.append(parsed)
                except (ValueError, KeyError, TypeError) as error:
                    validity[str(error) if isinstance(error, ValueError) else type(error).__name__] += 1
                    parsed_reviews.append(None)
        response = trial.get('response') or {}
        review = response.get('evidence_review') or {}
        if trial['arm'] == 'baseline':
            check(not review and not trial.get('snapshots') and not parsed_reviews, identity, 'baseline_has_no_reviewer')
        else:
            check(len(parsed_reviews) <= 2 and review.get('repairs', 0) <= 1, identity, 'finite_workflow')
            if review.get('status') == 'unverified':
                unverified[review.get('reason', 'missing_reason')] += 1
            snapshots = trial.get('snapshots', [])
            if response and snapshots:
                final = snapshots[-1]
                fingerprint = digest({'query': question['query'], 'items': final['items'], 'evidence': response.get('evidence', [])})
                check(fingerprint == final['fingerprint'] == review.get('evidence_fingerprint'), identity, 'exact_final_public_fingerprint')
                if review.get('status') in ('sufficient', 'insufficient'):
                    check(bool(parsed_reviews) and parsed_reviews[-1] is not None, identity, 'valid_claim_has_valid_final_model_review')
                    if parsed_reviews and parsed_reviews[-1] is not None:
                        check(all(review.get(key) == parsed_reviews[-1][key] for key in ('status', 'reason', 'coverage')), identity, 'public_claim_matches_valid_final_review')
                    sources = [{key: value for key, value in row.items() if key != 'text'} for row in final['items']]
                    check(review.get('sources') == sources, identity, 'final_sources_match_review')
                    items = {row['evidence_id']: row for row in final['items']}
                    for facet in review.get('coverage', []):
                        for citation in facet['citations']:
                            check(citation['evidence_id'] in items and citation['quote'] in items.get(citation['evidence_id'], {}).get('text', ''), identity, 'canonical_quote_in_final_evidence')
        records.append({'id': identity, 'error': trial.get('error'), 'stop': response.get('stop_reason'),
            'claim': review.get('status'), 'attempts': review.get('attempts'), 'repairs': review.get('repairs'),
            'full_read_receipts': scope.get('exact_full_reads') if isinstance(scope, dict) else None,
            'source_units': scope.get('source_units') if isinstance(scope, dict) else None,
            'all_scoped_text_read': scope.get('all_scoped_text_read') if isinstance(scope, dict) else None,
            'usage_complete': trial.get('provider_usage', {}).get('usage_complete')})
    return {'protocol_digest': digest(protocol), 'planned': len(expected), 'recorded': len(trials),
        'current_source_fingerprints_checked': len(source_checks) if source_checks is not None else None,
        'call_counts': dict(call_counts), 'independent_review_schema_validation': dict(validity),
        'review_unverified_reasons': dict(unverified),
        'provider_length_finishes': sum('length' in row.get('finish_reasons', []) for row in all_calls),
        'calls_with_unknown_response_or_usage': sum(row.get('usage') is None for row in all_calls),
        'calls_without_observed_returned_model': sum(row.get('returned_model') is None for row in all_calls),
        'failed_episodes_with_unknown_scope_history': unknown_scope_history,
        'failed_episodes_without_completed_tool_step_history': [row['id'] for row in trials if row.get('error')],
        'errors': errors, 'passed': not errors, 'records': records,
        'interpretation': 'Deterministic recorded-source/schema/fingerprint audit, not semantic truth, budget policy, new model output or replacement verdict. Failed API episodes preserve weaker/unknown call and step evidence.'}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiment', type=Path, required=True)
    parser.add_argument('--split', choices=('development', 'held_out'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--current-sources', action='store_true')
    args = parser.parse_args()
    result = audit(args)
    with args.output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({key: value for key, value in result.items() if key != 'records'}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result['passed'] else 1)
