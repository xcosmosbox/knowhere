"""Await the existing evaluation, then audit/archive its completed evidence once."""
from __future__ import annotations

import json
import os
import subprocess
import time
from pathlib import Path

RUN = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
EXPERIMENT = RUN / 'rfc-heldout-scoped-v3'
ROOT = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
DOCS = ROOT / 'docs/experiments/evidence-review-2026-10-11'
PYTHON = '/Users/ottofeng/Desktop/knowhere/knowhere/.venv/bin/python'
FINALIZER_PID = 37456

def active(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False

summary_path = EXPERIMENT / 'summary/summary.json'
print(json.dumps({'stage': 'evidence_archive', 'status': 'awaiting_existing_blind_evaluation'}), flush=True)
while active(FINALIZER_PID):
    time.sleep(20)
if not summary_path.is_file() or not (EXPERIMENT / 'summary/RESULTS.md').is_file():
    raise RuntimeError('Evaluation finalizer ended without its complete summary; retain failures and inspect before continuing')
completion = json.loads((EXPERIMENT / 'summary.log').read_text().strip())
if completion.get('episodes') != 144 or completion.get('questions') != 24:
    raise ValueError('Summary command did not log the full frozen denominator')
summary = json.loads(summary_path.read_text())
validation = summary['validation']
if (validation['actual_episodes'] != 144 or validation['expected_episodes'] != 144
        or validation['negative_controls_passed'] != 3
        or validation['runtime_gate_failure_trial_ids']):
    raise ValueError('Do not finalize a partial frozen denominator')
environment = {**os.environ, 'DYLD_LIBRARY_PATH': str(RUN / 'libpq'), 'DS_KEY': 'offline-audit-placeholder'}

def execute(stage: str, command: list[str], *, allow_findings: bool = False) -> int:
    print(json.dumps({'stage': stage, 'status': 'starting'}), flush=True)
    status = subprocess.run(command, env=environment, cwd=ROOT).returncode
    print(json.dumps({'stage': stage, 'exit_code': status}), flush=True)
    if status and not (allow_findings and status == 1):
        raise SystemExit(status)
    return status

execute('offline_source_audit', [PYTHON, str(RUN / 'audit_frozen_results.py'),
    '--experiment', str(EXPERIMENT), '--split', 'held_out', '--current-sources',
    '--output', str(RUN / 'heldout-source-audit.json')])
execute('heldout_archive', [PYTHON, str(RUN / 'archive_records.py'), '--group', 'mac-heldout-records'])
environment.pop('GITLEAKS_CONFIG', None)
environment.pop('GITLEAKS_CONFIG_TOML', None)
scan_path = RUN / 'archive-scan-final.json'
scanner_status = execute('archive_recursive_scan', [str(RUN / 'gitleaks'), 'dir', str(DOCS),
    '--gitleaks-ignore-path', str(DOCS), '--ignore-gitleaks-allow', '--max-archive-depth', '2',
    '--no-banner', '--redact=100', '--report-format', 'json', '--report-path', str(scan_path)], allow_findings=True)
execute('scan_finding_classification', [PYTHON, str(RUN / 'classify_archive_scan.py'),
    '--scan', str(scan_path), '--output', str(RUN / 'archive-scan-final-classification.json')])
source_audit = json.loads((RUN / 'heldout-source-audit.json').read_text())
scan_audit = json.loads((RUN / 'archive-scan-final-classification.json').read_text())
if not source_audit['passed'] or source_audit['recorded'] != 144 or scan_audit['unresolved']:
    raise ValueError('Unresolved source/archive findings block release')
manifests = []
for path in sorted(DOCS.glob('mac-*.manifest.json')):
    manifest = json.loads(path.read_text())
    manifests.append({'manifest': path.name, 'archive': manifest['archive'], 'sha256': manifest['sha256'],
                      'bytes': manifest['bytes'], 'entries': len(manifest['entries'])})
result = {'status': 'complete_archived_and_source_audited', 'retrieval_episodes': 144,
          'archive_manifests': manifests, 'scanner_exit_code': scanner_status,
          'semantic_negative_controls_passed': validation['negative_controls_passed'],
          'interpretation': 'Evidence pipeline completed. Final findings/report interpretation, Git commit/push and final PR wording still require the primary agent; no merge or external write by this script.'}
with (RUN / 'evidence-release-observation.json').open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result), flush=True)
