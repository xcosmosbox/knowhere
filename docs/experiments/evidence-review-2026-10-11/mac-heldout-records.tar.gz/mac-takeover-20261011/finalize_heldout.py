"""Await the existing frozen run, then invoke its unchanged blind judge once.

This does not start/resend retrieval episodes, retry assessments, change source,
impose a deadline, or modify PRs. Failures and unknowns retain their denominators.
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

RUN = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
ROOT = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
EXPERIMENT = RUN / 'rfc-heldout-scoped-v3'
PYTHON = '/Users/ottofeng/Desktop/knowhere/knowhere/.venv/bin/python'
TRIALS = [EXPERIMENT / f'shard-{shard}/trials.jsonl' for shard in range(3)]
WORKERS = [28295, 28296, 28298]
PROTOCOL = EXPERIMENT / 'protocol.json'
GOLD = ROOT / 'scripts/fixtures/evidence_review_rfc_20261011/gold.json'
PROFILE = 'provider-max-scoped-thinking'
protocol = json.loads(PROTOCOL.read_text())
expected = {f'{row["question_id"]}:{row["repeat"]}:{arm}'
            for row in protocol['schedule'] if row['split'] == 'held_out' for arm in row['order']}
assert len(expected) == 144

def read_trials() -> list[dict]:
    records = []
    for path in TRIALS:
        if path.exists():
            with path.open() as stream:
                for line in stream:
                    if line.endswith('\n'):
                        records.append(json.loads(line))
    identities = [row['id'] for row in records]
    if len(identities) != len(set(identities)) or set(identities) - expected:
        raise ValueError('Unexpected/duplicate retrieval identity')
    if any(not all(row.get('gates', {}).values()) for row in records):
        raise ValueError('Retained policy-gate failure; do not score as a successful run')
    return records

def alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False

last = None
while True:
    records = read_trials()
    counts = (len(records), sum(bool(row.get('error')) for row in records))
    active = [pid for pid in WORKERS if alive(pid)]
    if counts != last:
        print(json.dumps({'stage': 'retrieval', 'at': datetime.now(timezone.utc).isoformat(),
                          'completed': counts[0], 'planned': 144, 'delivery_errors': counts[1],
                          'active_worker_processes': active}), flush=True)
        last = counts
    if len(records) == 144 and not active:
        break
    if len(records) < 144 and not active:
        raise RuntimeError('Existing workers ended before all frozen identities were recorded; inspect journals, never replace started IDs')
    # No experiment deadline; this is only a bounded local observation interval.
    time.sleep(20)

revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
if revision != protocol['git_revision']:
    raise ValueError('Retrieval checkout revision drifted before blind evaluation')
mismatches = [path for path, expected_hash in protocol['runtime_source_sha256'].items()
              if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != expected_hash]
if mismatches or hashlib.sha256(GOLD.read_bytes()).hexdigest() != protocol['gold_sha256']:
    raise ValueError('Frozen input/source mismatch before blind evaluation')
if (EXPERIMENT / 'assessments').exists() or (EXPERIMENT / 'summary').exists():
    raise ValueError('Do not overwrite or implicitly retry an existing evaluation')

commands = [
    ('evaluation', [PYTHON, 'scripts/evidence_review_benchmark/evaluate.py',
        '--key-file', '/Users/ottofeng/.config/knowhere/deepseek-test.key', '--gold', str(GOLD),
        '--protocol', str(PROTOCOL), '--resource-profile', PROFILE,
        '--trials', *(str(path) for path in TRIALS), '--output', str(EXPERIMENT / 'assessments'), '--concurrency', '4']),
    ('summary', [PYTHON, 'scripts/evidence_review_benchmark/summarize.py',
        '--gold', str(GOLD), '--protocol', str(PROTOCOL), '--split', 'held_out',
        '--pricing-date', '2026-10-11', '--trials', *(str(path) for path in TRIALS),
        '--assessments', str(EXPERIMENT / 'assessments'), '--output', str(EXPERIMENT / 'summary')]),
]
for stage, command in commands:
    print(json.dumps({'stage': stage, 'status': 'starting'}), flush=True)
    log_path = EXPERIMENT / f'{stage}.log'
    with log_path.open('x') as log:
        process = subprocess.Popen(command, cwd=ROOT,
            env={**os.environ, 'DYLD_LIBRARY_PATH': str(RUN / 'libpq')},
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        for line in process.stdout:
            log.write(line)
            log.flush()
            print(line, end='', flush=True)
        status = process.wait()
    print(json.dumps({'stage': stage, 'status': 'completed' if status == 0 else 'failed',
                      'exit_code': status, 'log': str(log_path)}), flush=True)
    if status != 0:
        raise SystemExit(status)
print(json.dumps({'stage': 'finalization', 'status': 'blind_evaluation_and_summary_complete',
                  'interpretation': 'Archive and result/source/claim audit still required.'}), flush=True)
