# Frozen held_out evidence-review results

Descriptive results for 24 frozen held_out questions, 3 repeats and two arms (144 episodes). Repeats are averaged within questions. There are 2 document families; no population significance claim or p-value is made.

| Stratum | Baseline confirmed sufficient | Review confirmed sufficient | Paired sufficiency delta (percentage points) | Paired semantic coverage delta (percentage points) |
|---|---:|---:|---:|---:|
| All held_out | 52/72 | 52/72 | unknown | unknown |
| json | 25/36 | 26/36 | 2.778 | unknown |
| quic | 27/36 | 26/36 | unknown | unknown |

Confirmed counts are lower bounds if semantic scores are unknown. Delivery failures remain in the scheduled denominator; unknown assessments are reported separately and are not treated as definite semantic failures.

| Arm | Answerable sufficient | Unknown semantic scores | Delivery errors | Latency p50/p95 (s) | Observed real tokens | Complete usage | Estimated USD |
|---|---:|---:|---:|---:|---:|---|---:|
| baseline | 52/60 | 2 | 2 | 279.651/2,799.529 | 16,328,346 | false | unknown |
| review | 52/60 | 7 | 5 | 294.459/3,971.227 | 24,279,001 | false | unknown |

Review made 51 sufficient claims: 0 independently false among 49 scored claims, with 2 unverified claims. False-insufficient decisions: 0 among 52 independently sufficient delivered packets.

Observed first-to-final sufficiency flips: 0 among 4 recorded initially insufficient first finishes. Among 4 actual correction attempts, 0 became sufficient, including 0 with changed evidence. This is not an independent budget-eligibility estimate; 0 unchanged-evidence flips may reflect evaluator variability. Initial unknown scores: 0; relevant final unknown scores: 0. Incremental estimated USD per additional sufficient delivery: unknown.

Offline semantic evaluation is separate: 155 real provider calls, estimated USD 0.293; none of this cost is added to retrieval overhead. All three explicit semantic negative controls passed.

Costs are list-rate estimates, not bills. The separately versioned 2026-10-11 UTC price record (Sunday, all-day off-peak) applies only to matching dated calls. Missing usage or other dates leave the total cost unknown. Offline scoring is separate.

The corpus mechanically covers the full frozen source documents; it is not selected by gold answers. Both arms receive the same known document scope. This tests the production retrieval core on PGlite, not visual parsing, HTTP workers, native PostgreSQL concurrency or production traffic. The separate blind judge shares the DeepSeek model family, so correlated errors remain possible. Literal span recall is not semantic correctness; normative text is not a production-traffic sample.

Both arms use the frozen resource intervention: Explicit experimental resource intervention; not production defaults or historical 15-step results. null means no local resource limit. Scoped profile additionally reports the full permitted document inventory and exact full-read completeness to both arms; no gold facts, forced verdict, step/time limit or synthetic tool response. Natural finish/error/cancellation ends an episode; failed or invalid calls are not retried. This is not directly comparable with historical 15-step/non-thinking results. Development and infrastructure failures are retained separately from held-out benefit metrics.
