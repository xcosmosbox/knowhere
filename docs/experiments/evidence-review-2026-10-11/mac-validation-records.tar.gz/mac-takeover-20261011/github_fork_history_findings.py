"""Inspect only metadata from the fork's existing redacted Gitleaks artifact."""
from __future__ import annotations

import collections
import hashlib
import io
import json
import os
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
REPO = Path('/Users/ottofeng/Desktop/knowhere/production-source-spans')
OUTPUT = ROOT / 'fork-gitleaks-history-metadata.json'
if OUTPUT.exists():
    raise SystemExit('Do not replace a historical observation')
result = {'observed_at': datetime.now(timezone.utc).isoformat(),
          'repository': 'xcosmosbox/knowhere', 'run_id': 38106023862,
          'feature_revision': 'd4d32ad74091b4040e1a1e8d7dae10f6a5b222c1',
          'observations': [], 'reports': []}
try:
    credential = subprocess.run(['git', 'credential', 'fill'], cwd=REPO,
        input='protocol=https\nhost=github.com\npath=xcosmosbox/knowhere.git\n\n',
        env={**os.environ, 'GIT_TERMINAL_PROMPT': '0'}, capture_output=True, text=True, check=True)
    token = dict(line.split('=', 1) for line in credential.stdout.splitlines() if '=' in line)['password']
    with httpx.Client(base_url='https://api.github.com', timeout=30,
        headers={'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github+json',
                 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'knowhere-project-verification'}) as client:
        endpoint = '/repos/xcosmosbox/knowhere/actions/runs/38106023862/artifacts'
        response = client.get(endpoint)
        result['observations'].append({'endpoint': endpoint, 'http_status': response.status_code})
        response.raise_for_status()
        selected = [item for item in response.json()['artifacts'] if item['name'] == 'gitleaks-redacted-findings']
        if len(selected) != 1:
            raise ValueError('Expected exactly one run-scoped redacted artifact')
        item = selected[0]
        endpoint = f'/repos/xcosmosbox/knowhere/actions/artifacts/{item["id"]}/zip'
        response = client.get(endpoint)
        observation = {'endpoint': endpoint, 'http_status': response.status_code,
                       'artifact': {key: item.get(key) for key in ('id', 'name', 'size_in_bytes', 'expired', 'digest')}}
        if response.is_redirect:
            response = httpx.get(response.headers['location'], timeout=30)
            observation['download_status'] = response.status_code
        result['observations'].append(observation)
        response.raise_for_status()
        result['redacted_zip_sha256'] = hashlib.sha256(response.content).hexdigest()
        # Do not extract files, persist Match/Secret fields, or copy log text.
        with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
            for name in archive.namelist():
                if not name.endswith('.json'):
                    continue
                data = json.loads(archive.read(name))
                if not isinstance(data, list):
                    raise ValueError('Invalid redacted scan report')
                findings = [{key: row.get(key) for key in ('RuleID', 'File', 'StartLine', 'EndLine', 'Commit', 'Fingerprint')}
                            for row in data]
                result['reports'].append({'name': name, 'findings': findings})
    ancestry = {}
    commits = sorted({finding['Commit'] for report in result['reports'] for finding in report['findings'] if finding.get('Commit')})
    for commit in commits:
        present = subprocess.run(['git', 'cat-file', '-e', f'{commit}^{{commit}}'], cwd=REPO, capture_output=True).returncode == 0
        ancestry[commit] = {'present_locally': present}
        if present:
            for label, ref in (('ancestor_of_original_feature', 'f68cee2d2793dc4d6fa5cb9281f3d6d357826b1b'),
                               ('ancestor_of_final_feature', result['feature_revision']),
                               ('ancestor_of_synced_main', '65c0445a76c9b17b365646dfc285fe08c7aa3acf')):
                status = subprocess.run(['git', 'merge-base', '--is-ancestor', commit, ref], cwd=REPO, capture_output=True).returncode
                ancestry[commit][label] = True if status == 0 else False if status == 1 else None
    result['commit_ancestry'] = ancestry
    result['status'] = 'observed'
except Exception as error:
    result.update(status='unavailable', error_type=type(error).__name__)
with OUTPUT.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
findings = [row for report in result['reports'] for row in report['findings']]
print(json.dumps({'status': result['status'], 'output': str(OUTPUT),
    'reports': [{'name': report['name'], 'count': len(report['findings'])} for report in result['reports']],
    'rules': dict(collections.Counter(row['RuleID'] for row in findings)),
    'files': dict(collections.Counter(row['File'] for row in findings)),
    'commit_ancestry': result.get('commit_ancestry', {})}, ensure_ascii=False, indent=2))
