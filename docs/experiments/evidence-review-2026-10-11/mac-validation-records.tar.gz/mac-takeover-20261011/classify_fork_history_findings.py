"""Prove whether redacted findings are source fingerprints, without secrets."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
REPO = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
OUTPUT = ROOT / 'fork-gitleaks-fingerprint-classification.json'
if OUTPUT.exists():
    raise SystemExit('Do not overwrite a completed classification')
input_path = ROOT / 'fork-gitleaks-history-metadata.json'
metadata = json.loads(input_path.read_text())
records = []
for report in metadata['reports']:
    for finding in report['findings']:
        commit, file = finding['Commit'], finding['File']
        raw = subprocess.check_output(['git', 'show', f'{commit}:{file}'], cwd=REPO)
        protocol = json.loads(raw)
        text = raw.decode().splitlines()[finding['StartLine'] - 1]
        match = re.fullmatch(r'\s*"([^"\n]+)":\s*"([a-f0-9]{64})",?\s*', text)
        record = {**finding, 'matched_sha256_field': bool(match), 'source_fingerprint': False,
                  'source_hash_verified_at_same_commit': False}
        if match:
            source, value = match.groups()
            record['source_fingerprint'] = protocol.get('runtime_source_sha256', {}).get(source) == value
            if record['source_fingerprint']:
                source_bytes = subprocess.check_output(['git', 'show', f'{commit}:{source}'], cwd=REPO)
                record['source_hash_verified_at_same_commit'] = hashlib.sha256(source_bytes).hexdigest() == value
                record['source_path'] = source
        records.append(record)
result = {'input_sha256': hashlib.sha256(input_path.read_bytes()).hexdigest(),
    'findings': len(records), 'all_are_verified_source_fingerprints': all(row['source_fingerprint'] and row['source_hash_verified_at_same_commit'] for row in records),
    'records': records,
    'interpretation': 'Classification only; no workflow, scanner configuration, allowlist or Git history change. The remote fork check remains failed.'}
with OUTPUT.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in result.items() if key != 'records'}, indent=2))
