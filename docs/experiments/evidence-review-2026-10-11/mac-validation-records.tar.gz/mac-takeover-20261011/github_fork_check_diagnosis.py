"""Read only the failed Knowhere fork check, without exporting credentials/logs."""
from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import httpx

ROOT = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
OUTPUT = ROOT / 'fork-gitleaks-diagnosis.json'
if OUTPUT.exists():
    raise SystemExit('Keep the original observation; output already exists')

def safe_text(value: str) -> str:
    value = re.sub(r'(?i)\b(?:sk-|gh[pousr]_|github_pat_)[A-Za-z0-9_-]+', '[REDACTED]', value)
    value = re.sub(r'(?im)^.*(?:Secret:|Match:|Authorization:|password=|token=).*$','[REDACTED FIELD]',value)
    return value

result = {'observed_at': datetime.now(timezone.utc).isoformat(),
          'repository': 'xcosmosbox/knowhere',
          'feature_revision': 'd4d32ad74091b4040e1a1e8d7dae10f6a5b222c1',
          'authority': 'Project-scoped read-only diagnostic; existing Git credential helper.',
          'observations': []}
try:
    credential = subprocess.run(['git', 'credential', 'fill'],
        cwd='/Users/ottofeng/Desktop/knowhere/production-source-spans',
        input='protocol=https\nhost=github.com\npath=xcosmosbox/knowhere.git\n\n',
        env={**os.environ, 'GIT_TERMINAL_PROMPT': '0'}, capture_output=True, text=True, check=True)
    fields = dict(line.split('=', 1) for line in credential.stdout.splitlines() if '=' in line)
    token = fields['password']
    with httpx.Client(base_url='https://api.github.com', timeout=30,
        headers={'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github+json',
                 'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'knowhere-project-verification'}) as client:
        for endpoint in ('/repos/xcosmosbox/knowhere/check-runs/114371623077/annotations',
                         '/repos/xcosmosbox/knowhere/actions/runs/38106023862/jobs'):
            response = client.get(endpoint)
            item = {'endpoint': endpoint, 'http_status': response.status_code}
            if response.status_code == 200:
                data = response.json()
                if isinstance(data, list):
                    item['annotations'] = [{key: safe_text(str(row.get(key, '')))
                        for key in ('path', 'start_line', 'end_line', 'annotation_level', 'title', 'message')}
                        for row in data]
                else:
                    item['jobs'] = [{key: row.get(key) for key in
                        ('id', 'name', 'status', 'conclusion', 'head_sha', 'steps')}
                        for row in data.get('jobs', [])]
            result['observations'].append(item)
        endpoint = '/repos/xcosmosbox/knowhere/actions/jobs/114371623077/logs'
        response = client.get(endpoint)
        log_item = {'endpoint': endpoint, 'http_status': response.status_code}
        if response.is_redirect:
            # Never forward the GitHub authorization header to a signed log host.
            location = response.headers['location']
            response = httpx.get(location, timeout=30)
            log_item['download_status'] = response.status_code
        if response.status_code == 200:
            log_item['raw_log_sha256'] = hashlib.sha256(response.content).hexdigest()
            log_item['raw_log_bytes'] = len(response.content)
            # Narrow diagnostics only; do not save the full scan output or secret findings.
            relevant = re.compile(r'(?i)license|leaks found|no leaks|scan completed|gitleaks.*(?:error|fail)|fatal|##\[error\]')
            log_item['diagnostic_lines'] = [safe_text(line) for line in response.text.splitlines()
                                          if relevant.search(line)]
            log_item['raw_log_retained'] = False
        result['observations'].append(log_item)
    result['status'] = 'observed'
except Exception as error:
    result.update(status='unavailable', error_type=type(error).__name__)

with OUTPUT.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
