"""Await existing archive pipeline, verify all members, then prepare a draft once.

Does not launch/resend/retry model calls, commit, push, or modify a PR. No local
deadline. The primary agent must still review the draft and finalize delivery.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import time

RUN = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
ROOT = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
DOCS = ROOT / 'docs/experiments/evidence-review-2026-10-11'
PYTHON = '/Users/ottofeng/Desktop/knowhere/knowhere/.venv/bin/python'
ARCHIVE_PID = 93640
RELEASE = RUN / 'evidence-release-observation.json'


def emit(value):
    event = {'observed_at': datetime.now(timezone.utc).isoformat(), **value}
    with (RUN / 'report-preparation-events.jsonl').open('a') as stream:
        stream.write(json.dumps(event, ensure_ascii=False) + '\n')
        stream.flush()
    print(json.dumps(event, ensure_ascii=False), flush=True)


def active():
    try:
        os.kill(ARCHIVE_PID, 0)
    except ProcessLookupError:
        return False
    command = subprocess.check_output(['ps', '-p', str(ARCHIVE_PID), '-o', 'command='], text=True)
    return str(RUN / 'finish_evidence_archive.py') in command


try:
    emit({'stage': 'report_draft', 'status': 'awaiting_existing_archive_pipeline'})
    while not RELEASE.exists():
        if not active():
            raise RuntimeError('Existing archive pipeline ended without a complete release observation; retain evidence and inspect')
        time.sleep(20)
    release = json.loads(RELEASE.read_text())
    assert release['status'] == 'complete_archived_and_source_audited'
    assert release['retrieval_episodes'] == 144 and release['semantic_negative_controls_passed'] == 3
    assert json.loads((RUN / 'heldout-source-audit.json').read_text())['passed'] is True
    assert not json.loads((RUN / 'archive-scan-final-classification.json').read_text())['unresolved']
    archives = []
    for path in sorted(DOCS.glob('mac-*.manifest.json')):
        manifest = json.loads(path.read_text())
        archive = DOCS / manifest['archive']
        assert archive.is_file() and archive.parent == DOCS and not archive.is_symlink()
        assert archive.stat().st_size == manifest['bytes']
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['sha256']
        members = []
        names = set()
        with tarfile.open(archive) as tar:
            for member in tar:
                name = PurePosixPath(member.name)
                assert member.isfile() and not member.issym() and not member.islnk()
                assert not name.is_absolute() and '..' not in name.parts
                assert name.parts[0] == 'mac-takeover-20261011' and member.name not in names
                names.add(member.name)
                content = tar.extractfile(member).read()
                members.append({'path': member.name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()})
        assert members == manifest['entries']
        archives.append({'archive': archive.name, 'sha256': manifest['sha256'], 'entries': len(members), 'verified': True})
    assert len(archives) == 5 and any(row['archive'] == 'mac-heldout-records.tar.gz' for row in archives)
    with (RUN / 'final-archive-member-verification.json').open('x') as stream:
        json.dump({'status': 'passed', 'archives': archives, 'total_entries': sum(row['entries'] for row in archives)}, stream, indent=2)
        stream.write('\n')
    status = subprocess.run([PYTHON, str(RUN / 'prepare_benefit_report.py'),
        '--experiment', str(RUN / 'rfc-heldout-scoped-v3'), '--split', 'held_out',
        '--output', str(RUN / 'heldout-report-draft')], cwd=ROOT).returncode
    if status:
        raise RuntimeError(f'Independent accounting/report draft exited {status}; no retries or Git/PR writes performed')
    emit({'stage': 'report_draft', 'status': 'prepared_for_primary_agent_review',
          'report': str(RUN / 'heldout-report-draft/BENEFIT_REPORT.md'),
          'remaining': 'Interpretation review, final documents, supplemental release evidence, normal experiment-branch push and PR text update.'})
except BaseException as error:
    emit({'stage': 'report_draft', 'status': 'failed', 'error_type': type(error).__name__})
    raise
