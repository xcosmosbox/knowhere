"""Independently cross-check completed raw accounting and prepare a report draft.

No model, production parser, retries, changed verdicts, Git or PR writes. All
outputs use exclusive creation. This is descriptive accounting, not semantic
ground truth; the original blind assessments remain the source of semantics.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion')
FIELDS = ('prompt_tokens', 'completion_tokens', 'total_tokens',
          'prompt_cache_hit_tokens', 'prompt_cache_miss_tokens')
RATE = {'prompt_cache_hit_tokens': .003, 'prompt_cache_miss_tokens': .15,
        'completion_tokens': .6}


def load(path):
    return json.loads(path.read_text())


def lines(path):
    data = path.read_text()
    if data and not data.endswith('\n'):
        raise ValueError('Incomplete final JSONL line')
    return [json.loads(line) for line in data.splitlines()]


def index(records, field):
    result = {row[field]: row for row in records}
    assert len(result) == len(records), 'Duplicate identity'
    return result


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def same(left, right):
    if isinstance(left, float) or isinstance(right, float):
        assert left is not None and right is not None and abs(left - right) < 1e-10
    else:
        assert left == right, (left, right)


def utc_elapsed_ms(row):
    try:
        began = datetime.fromisoformat(row['started_at'].replace('Z', '+00:00'))
        ended = datetime.fromisoformat(row['ended_at'].replace('Z', '+00:00'))
        if began.tzinfo is None or ended.tzinfo is None or ended < began:
            return None
        return (ended - began).total_seconds() * 1000
    except (KeyError, TypeError, ValueError, AttributeError):
        return None


def distribution(values):
    known = sorted(float(value) for value in values if type(value) in (int, float))
    def percentile(fraction):
        if not known:
            return None
        position = (len(known) - 1) * fraction
        low = int(position)
        high = min(low + 1, len(known) - 1)
        return known[low] + (known[high] - known[low]) * (position - low)
    return {'observed': len(known), 'unknown': len(values) - len(known),
            'mean': statistics.mean(known) if known else None,
            'p50': percentile(.5), 'p95': percentile(.95),
            'percentile_method': 'linear interpolation of observed episode values'}


def semantic(assessment, packet, question):
    score = assessment['semantic']
    if packet.get('limitations') or score.get('status') != 'valid':
        return None, None
    requirements = index(score['requirements'], 'id')
    assert set(requirements) == {row['id'] for row in question['requirements']}
    statuses = [row['status'] for row in requirements.values()]
    assert all(value in ('supported', 'missing', 'conflicting') for value in statuses)
    sufficient = all(value == 'supported' for value in statuses)
    coverage = statuses.count('supported') / len(statuses)
    same(sufficient, score['all_supported'])
    same(coverage, score['semantic_coverage'])
    return sufficient, coverage


def literal_coverage(packet):
    covered = 0
    for requirement in packet['gold_requirements']:
        supported = False
        for proof in requirement['proofs']:
            assert proof['quotes'] and all(isinstance(quote, str) and quote for quote in proof['quotes'])
            owned = [item for item in packet['evidence_items'] if item.get('doc_key') == proof['doc_key']
                     and item.get('original_chunk_id') == proof['chunk_id']]
            if all(any(quote in item['text'] for item in owned) for quote in proof['quotes']):
                supported = True
        covered += supported
    return covered / len(packet['gold_requirements'])


def usage(records, *, kind=None):
    calls = [call for row in records for call in row.get('provider_calls', [])
             if kind is None or call['kind'] == kind]
    totals = {field: 0 for field in FIELDS}
    unknown_usage = unknown_cost = reasoning_unknown = 0
    known_cost = 0.0
    reasoning = 0
    dates = Counter()
    for call in calls:
        assert call['requested_model'] == 'deepseek-flash'
        assert call.get('returned_model') in (None, 'deepseek-flash')
        assert call['max_tokens'] == 393216
        assert call['thinking'] == {'type': 'enabled'} and call['reasoning_effort'] == 'max'
        assert call.get('temperature') is None
        assert isinstance(call.get('transport_timeout'), dict)
        assert all(value is None for value in call['transport_timeout'].values())
        value = call.get('usage') or {}
        for field in FIELDS:
            if type(value.get(field)) is int and value[field] >= 0:
                totals[field] += value[field]
        complete = (all(type(value.get(field)) is int and value[field] >= 0 for field in FIELDS)
                    and value['prompt_tokens'] + value['completion_tokens'] == value['total_tokens']
                    and value['prompt_cache_hit_tokens'] + value['prompt_cache_miss_tokens'] == value['prompt_tokens'])
        unknown_usage += not complete
        details = value.get('completion_tokens_details') or {}
        thought = details.get('reasoning_tokens')
        if type(thought) is int and thought >= 0:
            reasoning += thought
        else:
            reasoning_unknown += 1
        eligible_date = False
        try:
            began = datetime.fromisoformat(call['started_at'].replace('Z', '+00:00'))
            ended = datetime.fromisoformat(call['ended_at'].replace('Z', '+00:00'))
            assert began.tzinfo is not None and ended.tzinfo is not None
            start_date = began.astimezone(timezone.utc).date().isoformat()
            end_date = ended.astimezone(timezone.utc).date().isoformat()
            dates[start_date + '/' + end_date] += 1
            eligible_date = start_date == end_date == '2026-10-11'
        except (KeyError, ValueError, TypeError, AssertionError):
            dates['unknown'] += 1
        if complete and eligible_date and call.get('returned_model') == 'deepseek-flash':
            known_cost += sum(value[field] * rate / 1_000_000 for field, rate in RATE.items())
        else:
            unknown_cost += 1
    # A record missing captured usage can conceal uncaptured calls. Do not
    # declare aggregate completeness merely because its captured calls agree.
    complete = unknown_usage == 0 and all(row.get('provider_usage', {}).get('usage_complete') is True for row in records)
    cost_complete = complete and unknown_cost == 0
    return {'calls': len(calls), 'observed_tokens': totals, 'usage_complete': complete,
            'calls_with_incomplete_usage': unknown_usage,
            'records_with_unknown_usage': sum(row.get('provider_usage', {}).get('usage_complete') is not True for row in records),
            'known_dated_estimate_usd': known_cost, 'unknown_cost_calls': unknown_cost,
            'complete_dated_estimate_usd': known_cost if cost_complete else None,
            'observed_reasoning_tokens': reasoning, 'reasoning_metadata_unknown_calls': reasoning_unknown,
            'observed_utc_start_end_dates': dict(dates)}


def macro(rows, field):
    grouped = {}
    for row in rows:
        grouped.setdefault(row['question_id'], []).append(row[field])
    lower, upper = [], []
    for values in grouped.values():
        known = [float(value) for value in values if value is not None]
        lower.append(sum(known) / len(values))
        upper.append((sum(known) + len(values) - len(known)) / len(values))
    return {'lower': statistics.mean(lower), 'upper': statistics.mean(upper),
            'unknown_episodes': sum(row[field] is None for row in rows)}


def check(args):
    experiment = args.experiment
    protocol = load(experiment / 'protocol.json')
    summary = load(experiment / 'summary/summary.json')
    gold_path = ROOT / 'scripts/fixtures/evidence_review_rfc_20261011/gold.json'
    gold = load(gold_path)
    same(sha(gold_path), protocol['gold_sha256'])
    questions = index(gold['questions'], 'id')
    planned = {f'{row["question_id"]}:{row["repeat"]}:{arm}' for row in protocol['schedule']
               if row['split'] == args.split for arm in row['order']}
    paths = sorted(experiment.glob('shard-*/trials.jsonl')) if args.split == 'held_out' else [experiment / 'development/trials.jsonl']
    trials = index([row for path in paths for row in lines(path)], 'id')
    starts = index([row for path in paths for row in lines(path.with_name('started.jsonl'))], 'id')
    same(set(trials), planned)
    same(set(starts), planned)
    same(summary['validation']['actual_episodes'], len(planned))
    same(summary['validation']['expected_episodes'], len(planned))
    same(summary['validation']['runtime_gate_failure_trial_ids'], [])
    for path, expected in summary['validation']['input_sha256'].items():
        target = Path(path)
        same(sha(target if target.is_absolute() else ROOT / target), expected)
    assessments_dir = experiment / 'assessments'
    mappings = index(lines(assessments_dir / 'trial-packets.jsonl'), 'trial_id')
    packets = index(lines(assessments_dir / 'blind-packets.jsonl'), 'packet_sha256')
    assessments = index(lines(assessments_dir / 'assessments.jsonl'), 'id')
    assessment_starts = index(lines(assessments_dir / 'started.jsonl'), 'id')
    controls = {f'negative-control-{number}' for number in range(3)}
    same(set(mappings), planned)
    same(set(assessments), set(packets) | controls)
    same(set(assessment_starts), set(assessments))
    for identity in controls:
        result = assessments[identity]
        assert result['negative_control'] is True and result['negative_control_passed'] is True
        assert result['semantic']['status'] == 'valid' and result['semantic']['all_supported'] is False
        same({row['id']: row['status'] for row in result['semantic']['requirements']},
             {'negative.production': 'missing', 'negative.retention': 'supported', 'negative.growth': 'missing'})
        assert result['provider_calls'], 'Controls must have real captured model calls'
    assessment_call_ids = []
    for identity, result in assessments.items():
        for call in result.get('provider_calls', []):
            same(call['trial_id'], identity)
            assessment_call_ids.append(call['call_id'])
    same(len(assessment_call_ids), len(set(assessment_call_ids)))
    for identity, packet in packets.items():
        encoded = json.dumps({key: value for key, value in packet.items() if key != 'packet_sha256'},
                             sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()
        same(hashlib.sha256(encoded).hexdigest(), identity)
    saved_cases = index(summary['case_audit'], 'trial_id')
    same(set(saved_cases), planned)
    observed = []
    for identity, trial in trials.items():
        assert trial['gates'] and all(value is True for value in trial['gates'].values())
        question = questions[trial['question_id']]
        mapping = mappings[identity]
        same(mapping['delivery_error'], trial.get('error'))
        final_packet = packets[mapping['final_packet']]
        same(final_packet['query'], question['query'])
        same([{key: requirement[key] for key in ('id', 'text', 'proofs')} for requirement in final_packet['gold_requirements']],
             [{key: requirement[key] for key in ('id', 'text', 'proofs')} for requirement in question['requirements']])
        sufficient, coverage = semantic(assessments[mapping['final_packet']], final_packet, question)
        response = trial.get('response') or {}
        review = response.get('evidence_review')
        claim = review.get('status') if isinstance(review, dict) else ('disabled' if trial['arm'] == 'baseline' else 'missing')
        attempts = review.get('attempts') if isinstance(review, dict) else None
        repairs = review.get('repairs') if isinstance(review, dict) else None
        if trial['arm'] == 'review' and isinstance(review, dict):
            assert type(attempts) is int and 0 <= attempts <= 2
            assert type(repairs) is int and 0 <= repairs <= 1
        first = mapping.get('first_packet')
        same(bool(first), bool(trial['arm'] == 'review' and isinstance(review, dict)
                               and attempts > 0 and len(trial.get('snapshots', [])) >= 2))
        initially = semantic(assessments[first], packets[first], question)[0] if first else None
        changed = (sorted((item['evidence_id'], item['text']) for item in packets[first]['evidence_items']) !=
                   sorted((item['evidence_id'], item['text']) for item in final_packet['evidence_items'])) if first else None
        delivered = False if trial.get('error') is not None else sufficient
        utc_duration = utc_elapsed_ms(trial)
        recorded_duration = trial.get('duration_ms')
        clock_delta = utc_duration - recorded_duration if utc_duration is not None and type(recorded_duration) in (int, float) else None
        literal = literal_coverage(final_packet)
        saved_literal = assessments[mapping['final_packet']].get('span')
        if saved_literal is not None:
            same(literal, saved_literal['coverage'])
        row = {'trial_id': identity, 'question_id': trial['question_id'], 'arm': trial['arm'],
               'family': question['cluster_id'].split('/', 1)[0], 'answerability': question['answerability'],
               'delivered_sufficient': delivered, 'semantic_sufficient': sufficient,
               'semantic_coverage': coverage, 'literal_coverage': literal,
               'delivery_error': trial.get('error') is not None, 'claim': claim,
               'utc_elapsed_ms': utc_duration, 'recorded_monotonic_ms': recorded_duration,
               'utc_minus_recorded_ms': clock_delta,
               'attempts': attempts, 'repairs': repairs, 'first_eligible': bool(first),
               'initial_sufficient': initially, 'evidence_changed': changed,
               'unverified_reason': review.get('reason') if isinstance(review, dict) and claim == 'unverified' else None}
        saved = saved_cases[identity]
        for field in ('delivered_sufficient', 'literal_coverage', 'claim', 'first_eligible'):
            same(row[field], saved[field])
        same(sufficient, saved['semantic']['sufficient'])
        same(coverage, saved['semantic']['coverage'])
        same(changed, saved['first_to_final_evidence_changed'])
        observed.append(row)
    arms = {}
    for arm in ('baseline', 'review'):
        selected = [row for row in observed if row['arm'] == arm]
        raw = [trials[row['trial_id']] for row in selected]
        aggregate = summary['overall']['arms'][arm]
        counts = {'planned': len(selected), 'confirmed': sum(row['delivered_sufficient'] is True for row in selected),
                  'unknown_delivery_sufficiency': sum(row['delivered_sufficient'] is None for row in selected),
                  'unknown_semantic_scores': sum(row['semantic_sufficient'] is None for row in selected),
                  'delivery_errors': sum(row['delivery_error'] for row in selected)}
        for own, frozen in (('planned', 'scheduled_episodes'), ('confirmed', 'confirmed_delivered_sufficient'),
                            ('unknown_delivery_sufficiency', 'unknown_delivered_sufficiency'),
                            ('unknown_semantic_scores', 'unknown_semantic_assessments'), ('delivery_errors', 'delivery_failures')):
            same(counts[own], aggregate['all_scheduled'][frozen])
        macros = {field: macro(selected, field) for field in ('delivered_sufficient', 'semantic_coverage', 'literal_coverage')}
        accounting = usage(raw)
        same(accounting['observed_tokens'], aggregate['provider']['observed_tokens'])
        same(accounting['calls'], aggregate['provider']['calls'])
        same(accounting['usage_complete'], aggregate['provider']['usage_complete'])
        arms[arm] = {'counts': counts, 'macros': macros, 'provider': accounting,
                     'provider_by_role': {kind: usage(raw, kind=kind) for kind in ('explorer', 'reviewer')},
                     'latency_ms': aggregate['latency_ms'], 'stops': aggregate['stops'],
                     'utc_elapsed_ms': distribution([row['utc_elapsed_ms'] for row in selected]),
                     'clock_difference_ms': distribution([row['utc_minus_recorded_ms'] for row in selected]),
                     'episodes_with_utc_minus_recorded_over_1s': sum(row['utc_minus_recorded_ms'] is not None and row['utc_minus_recorded_ms'] > 1000 for row in selected),
                     'answerable_only': aggregate['answerable_only']}
        for field, frozen in (('semantic_coverage', 'semantic_requirement_coverage'), ('literal_coverage', 'literal_span_coverage')):
            same(macros[field]['lower'], aggregate[frozen]['question_macro_lower_bound'])
            same(macros[field]['upper'], aggregate[frozen]['question_macro_upper_bound'])
    reviewed = [row for row in observed if row['arm'] == 'review']
    sufficient_claims = [row for row in reviewed if row['claim'] == 'sufficient']
    insufficient_claims = [row for row in reviewed if row['claim'] == 'insufficient']
    scored_sufficient = [row for row in sufficient_claims if not row['delivery_error'] and row['semantic_sufficient'] is not None]
    scored_insufficient = [row for row in insufficient_claims if not row['delivery_error'] and row['semantic_sufficient'] is not None]
    corrected = [row for row in reviewed if row['repairs'] == 1]
    first = [row for row in reviewed if row['first_eligible']]
    incomplete_corrected = [row for row in corrected if row['initial_sufficient'] is False]
    claims = {'statuses': dict(Counter(row['claim'] for row in reviewed)),
              'sufficient_claims': len(sufficient_claims), 'scored_sufficient_claims': len(scored_sufficient),
              'unknown_sufficient_claims': len(sufficient_claims) - len(scored_sufficient),
              'false_sufficient': sum(row['semantic_sufficient'] is False for row in scored_sufficient),
              'insufficient_claims': len(insufficient_claims), 'scored_insufficient_claims': len(scored_insufficient),
              'unknown_insufficient_claims': len(insufficient_claims) - len(scored_insufficient),
              'false_insufficient': sum(row['semantic_sufficient'] is True for row in scored_insufficient),
              'valid_public_reviews': sum(row['claim'] in ('sufficient', 'insufficient') for row in reviewed),
              'unknown_public_attempt_counter': sum(row['attempts'] is None for row in reviewed),
              'unknown_public_correction_counter': sum(row['repairs'] is None for row in reviewed),
              'unverified_reasons': dict(Counter(row['unverified_reason'] for row in reviewed if row['unverified_reason']))}
    for own, frozen in (('false_sufficient', 'false_sufficient'), ('false_insufficient', 'false_insufficient'),
                        ('scored_sufficient_claims', 'independently_scored_sufficient_claims')):
        same(claims[own], summary['overall']['arms']['review']['review_claims'][frozen])
    corrections = {'all_observed_correction_attempts': len(corrected), 'recorded_first_snapshots': len(first),
                   'initial_sufficient': sum(row['initial_sufficient'] is True for row in first),
                   'initial_insufficient': sum(row['initial_sufficient'] is False for row in first),
                   'initial_unknown': sum(row['initial_sufficient'] is None for row in first),
                   'known_initial_insufficient_correction_attempts': len(incomplete_corrected),
                   'rescued': sum(row['delivered_sufficient'] is True for row in incomplete_corrected),
                   'rescued_with_changed_evidence': sum(row['delivered_sufficient'] is True and row['evidence_changed'] is True for row in incomplete_corrected),
                   'relevant_final_unknown': sum(row['delivered_sufficient'] is None for row in incomplete_corrected)}
    deltas = {field: {'lower': arms['review']['macros'][field]['lower'] - arms['baseline']['macros'][field]['upper'],
                      'upper': arms['review']['macros'][field]['upper'] - arms['baseline']['macros'][field]['lower']}
              for field in ('delivered_sufficient', 'semantic_coverage', 'literal_coverage')}
    for field in deltas:
        same(deltas[field]['lower'], summary['overall']['paired'][field]['mean_delta_lower_bound'])
        same(deltas[field]['upper'], summary['overall']['paired'][field]['mean_delta_upper_bound'])
    sleep_path = experiment.parent / 'host-sleep-observation.json'
    sleep = load(sleep_path) if args.split == 'held_out' and sleep_path.exists() else None
    return {'status': 'independent_accounting_crosscheck_passed', 'split': args.split,
            'runtime_revision': protocol['git_revision'], 'protocol_sha256': sha(experiment / 'protocol.json'),
            'summary_sha256': sha(experiment / 'summary/summary.json'), 'expected_episodes': len(planned),
            'questions': len({row['question_id'] for row in observed}), 'arms': arms, 'paired_bounds': deltas,
            'claims': claims, 'corrections': corrections, 'scoring': usage(list(assessments.values())),
            'semantic_negative_controls_passed': len(controls), 'unique_blind_packets': len(packets),
            'host_sleep_observation': sleep,
            'case_accounting': observed,
            'interpretation': 'Independent raw-record arithmetic only, not a second judge or human truth. Cross-date calls have unknown cost; original summaries and model verdicts are not modified. Missing public counters remain unknown, including failed review episodes.'}


def percent(value):
    return f'{value * 100:.2f}%'


def interval(values):
    return percent(values['lower']) if abs(values['upper'] - values['lower']) < 1e-12 else percent(values['lower']) + ' 至 ' + percent(values['upper'])


def difference(values):
    low, high = values['lower'] * 100, values['upper'] * 100
    return (f'{low:.2f}' if abs(high - low) < 1e-10 else f'{low:.2f} 至 {high:.2f}') + ' 个百分点'


def amount(value):
    return '未知' if value is None else f'{value:.6f}'


def report(result):
    a, b = result['arms']['baseline'], result['arms']['review']
    claim, correction = result['claims'], result['corrections']
    delta = result['paired_bounds']['delivered_sufficient']
    if result['split'] != 'held_out':
        conclusion = '这是开发记录的工具验证，不是确认收益报告。'
    elif delta['lower'] > 0:
        conclusion = '本冻结样本观察到审查开启组的充分交付率较高；这不是生产总体收益或单因素因果证明。'
    elif delta['upper'] < 0:
        conclusion = '本冻结样本观察到审查开启组的充分交付率较低；这不是生产总体退化或单因素因果证明。'
    elif delta['lower'] == delta['upper'] == 0:
        conclusion = '本冻结样本未观察到充分交付率净提升。'
    else:
        conclusion = '含未知评分的保守差异范围包含零，本冻结样本不能确认充分交付率净提升。'
    text = ['# Knowhere Mac 真实模型确认实验：收益报告草稿', '',
            '状态：原始记录与汇总的独立算术核对完成；仍须主 agent 完成来源/归档核对并审阅本草稿，才可作为最终交付。', '',
            conclusion, '',
            f'被测 revision：`{result["runtime_revision"]}`。{result["questions"]} 题，全部 {result["expected_episodes"]} 个冻结 episode；每题先平均重复，再配对两组。模型为 `deepseek-flash`，thinking enabled、reasoning_effort max、max_tokens=393216。无本地 DeepSeek 时间/步骤/金额/输入输出字节限额；两次审查和一次纠正是有限流程。', '',
            '## 质量与完整分母', '',
            '| 指标 | baseline | review |', '|---|---:|---:|']
    for label, field in [('确认充分交付', 'confirmed'), ('交付失败', 'delivery_errors'),
                         ('语义评分未知', 'unknown_semantic_scores'), ('充分交付状态未知', 'unknown_delivery_sufficiency')]:
        text.append(f'| {label} | {a["counts"][field]}/{a["counts"]["planned"]} | {b["counts"][field]}/{b["counts"]["planned"]} |')
    for label, field in [('充分交付率保守范围', 'delivered_sufficient'), ('语义 requirement coverage 题内宏平均范围', 'semantic_coverage'),
                         ('literal gold-span recall 题内宏平均范围', 'literal_coverage')]:
        text.append(f'| {label} | {interval(a["macros"][field])} | {interval(b["macros"][field])} |')
    text += ['', f'充分交付配对差异（review−baseline）保守范围：{difference(delta)}。交付失败是未交付充分证据，不自动证明潜在证据语义不足；语义未知不是零或通过。Literal recall 不能代替语义蕴含。', '',
             f'仅可回答题的确认充分交付：baseline {a["answerable_only"]["confirmed_delivered_sufficient"]}/{a["answerable_only"]["scheduled_episodes"]}，review {b["answerable_only"]["confirmed_delivered_sufficient"]}/{b["answerable_only"]["scheduled_episodes"]}。部分缺失题仍保留在主分母；相关 RFC 文字不能支持不存在的 operational measurement。', '',
             '## 公开声明与纠正', '',
             f'公开 review 状态：`{json.dumps(claim["statuses"], ensure_ascii=False, sort_keys=True)}`。有效最终公开审查 {claim["valid_public_reviews"]}/{b["counts"]["planned"]}。', '',
             f'False-sufficient {claim["false_sufficient"]}/{claim["scored_sufficient_claims"]} 个独立可评分充分声明，另有 {claim["unknown_sufficient_claims"]} 个声明评分未知；false-insufficient {claim["false_insufficient"]}/{claim["scored_insufficient_claims"]} 个独立可评分不足声明，另有 {claim["unknown_insufficient_claims"]} 个未知。零错误若出现，必须与这些分母和弃判率一起解读。', '',
             f'实际观察到 {correction["all_observed_correction_attempts"]} 次纠正；公开尝试/纠正计数缺失分别 {claim["unknown_public_attempt_counter"]}/{claim["unknown_public_correction_counter"]} 个回合，未填成零。记录了 {correction["recorded_first_snapshots"]} 个可盲评首次快照，其中初始充分/不足/未知 {correction["initial_sufficient"]}/{correction["initial_insufficient"]}/{correction["initial_unknown"]}。', '',
             f'在初始独立不足且实际纠正的 {correction["known_initial_insufficient_correction_attempts"]} 次中，{correction["rescued"]} 次最终充分，{correction["rescued_with_changed_evidence"]} 次同时改变证据，相关最终未知 {correction["relevant_final_unknown"]}。这不是所有可能纠正机会的独立估计；相同证据的评分翻转可能来自 judge 波动。', '',
             'unverified 的原始原因：', '', '```json', json.dumps(claim['unverified_reasons'], ensure_ascii=False, indent=2), '```', '',
             '## 用量、cache、延迟和日期费用', '',
             '| 角色 | calls | observed total tokens | cached input | uncached input | completion (含 thinking) | 完整费用 USD | 已知日期费用小计 USD | 未知费用 calls |',
             '|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    providers = [('baseline retrieval', a['provider']), ('review retrieval', b['provider']),
                 ('baseline explorer', a['provider_by_role']['explorer']), ('review explorer', b['provider_by_role']['explorer']),
                 ('review reviewer', b['provider_by_role']['reviewer']), ('独立盲评（含 controls）', result['scoring'])]
    for label, data in providers:
        value = data['observed_tokens']
        text.append(f'| {label} | {data["calls"]} | {value["total_tokens"]:,} | {value["prompt_cache_hit_tokens"]:,} | {value["prompt_cache_miss_tokens"]:,} | {value["completion_tokens"]:,} | {amount(data["complete_dated_estimate_usd"])} | {amount(data["known_dated_estimate_usd"])} | {data["unknown_cost_calls"]} |')
    text += ['', '用量缺失时表中 observed tokens 只是已知小计，不能假称完整用量。Reasoning token metadata 是 completion 的子集，不能再次计入总量或费用。价格是 UTC 2026-10-11 Sunday 每百万 cached/uncached/output USD 0.003/0.15/0.6 的列表估算，不是账单；跨日期或响应日期未知的 call 费用保持未知。不同角色用量无法从缺失 episode 精确拆分时，整体完整性也保留未知。', '',
             '任何一组完整费用未知时，不计算完整检索成本增幅或每额外充分回合成本；独立盲评不混入检索开销。', '',
             '| Arm | latency mean / p50 / p95 (s) | unknown latency |', '|---|---:|---:|']
    for name, arm in [('baseline', a), ('review', b)]:
        latency = arm['latency_ms']
        formatted = ' / '.join('未知' if latency[field] is None else f'{latency[field] / 1000:.3f}' for field in ('mean', 'p50', 'p95'))
        text.append(f'| {name} | {formatted} | {latency["unknown"]} |')
    text += ['', '上表是未改写的原始 `time.perf_counter()` duration。独立计算的 UTC elapsed：', '',
             '| Arm | UTC mean / p50 / p95 (s) | unknown UTC duration | UTC−recorded 大于 1s 的回合 |', '|---|---:|---:|---:|']
    for name, arm in [('baseline', a), ('review', b)]:
        elapsed = arm['utc_elapsed_ms']
        formatted = ' / '.join('未知' if elapsed[field] is None else f'{elapsed[field] / 1000:.3f}' for field in ('mean', 'p50', 'p95'))
        text.append(f'| {name} | {formatted} | {elapsed["unknown"]} | {arm["episodes_with_utc_minus_recorded_over_1s"]} |')
    if result.get('host_sleep_observation'):
        sleep = result['host_sleep_observation']['sleep']
        text += ['', f'主机电源日志：{sleep["started_at"]} 因 {sleep["reason"]} 睡眠 {sleep["recorded_sleep_seconds"]} 秒，{sleep["wake_at"]} {sleep["wake_type"]}。三个在途连接失败与此区间重叠，但未记录底层异常，不能证明唯一原因。原计时、失败及分母不剔除；该主机干扰使结果不能作为干净的生产延迟比较。防空闲睡眠断言不能阻止手动合盖，没有修改全局电源配置。']
    text += ['', f'Stops：baseline `{json.dumps(a["stops"], sort_keys=True)}`；review `{json.dumps(b["stops"], sort_keys=True)}`。no_tool_call 是真实流程终止，不伪造工具调用，不重新标为 token 截断，不重跑到通过。', '',
             '## 验证与局限', '',
             f'确认盲包去重后共 {result["unique_blind_packets"]} 包，另有 {result["semantic_negative_controls_passed"]} 次新鲜真实语义负控制。独立算术核对验证了完整日程、唯一启动 ID、输入 hash、provider 参数、评分映射、声明分母和题内配对范围；原模型判断和原始结果未修改。来源、精确引用和最终 fingerprint 由单独的 deterministic source audit 核对，不构成语义真值。', '',
             'Judge 使用新鲜的组别盲化 prompt 和独立冻结 gold，但与 explorer/reviewer 同属 DeepSeek 模型家族；负控制通过不保证全面可靠。JSON/QUIC 仅两个文档族，公开 RFC 可能在预训练中出现；这是实验未见题，不是保证模型未见数据。没有人类全量真值、p-value 或生产总体显著性声明。', '',
             '与历史运行相比，thinking、资源、lossless spans 和 closed-scope feedback 同时变化，不能把跨轮差异归因于一个因素。本轮两组只有 review_evidence 开关不同，但这只能描述新配置下的组间结果。生产默认限制和 default-off 未更改。', '',
             'Explorer 每动作重建 fresh system/user prompt，不保留 provider 原生 assistant/tool/reasoning_content 会话；两组共享该架构。真实 full-read receipts 不是充分性 gold，也不强制审查 verdict。实验覆盖真实检索核心和 PGlite，不包含 HTTP 鉴权/计费/上传解析 worker、live Cursor、native PostgreSQL 并发或生产流量。', '',
             '历史 300 回合、事后敏感性分析、两个开发协议和本次确认分开保存；开发 5/6 对 5/6 不充当留出收益。生产 CI/CodeQL 成功也不证明模型检索质量。最终归档、安全扫描分类、Git 推送及 PR 正文更新须另行核实。', '']
    return '\n'.join(text)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiment', type=Path, required=True)
    parser.add_argument('--split', choices=('development', 'held_out'), required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = check(args)
    args.output.mkdir(parents=True, exist_ok=True)
    with (args.output / 'independent-accounting.json').open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    with (args.output / 'BENEFIT_REPORT.md').open('x') as stream:
        stream.write(report(result))
    print(json.dumps({'status': result['status'], 'split': result['split'],
                      'episodes': result['expected_episodes'], 'output': str(args.output)}, ensure_ascii=False))
