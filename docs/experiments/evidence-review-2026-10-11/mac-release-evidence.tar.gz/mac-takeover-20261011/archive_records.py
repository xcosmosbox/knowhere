"""Build deterministic, explicitly scoped evidence archives after verification.

No database, environment, dependency checkout, credential, request header or
reasoning-content export is allowed. Original files and failed records are kept.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path, PurePosixPath

RUN = Path('/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML')
DOCS = Path('/Users/ottofeng/Desktop/knowhere/lab-scope-completion/docs/experiments/evidence-review-2026-10-11')
KEY = Path('/Users/ottofeng/.config/knowhere/deepseek-test.key')
DENIED_PARTS = {'db', 'db-0', 'db-1', 'db-2', '.venv', 'node_modules', '__pycache__', '.git'}
PEM_HEADER = re.compile(rb'(?m)^[ \t]*-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----[ \t]*\r?$')
PEM_BODY = re.compile(rb'-----BEGIN (?:[A-Z0-9]+ )*PRIVATE KEY-----[ \t]*(?:\r?\n|\\r\\n|\\n)[ \t]*[A-Za-z0-9+/=]{16,}')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def assert_public(path: Path, content: bytes, key: bytes) -> None:
    if path.is_symlink() or set(path.relative_to(RUN).parts) & DENIED_PARTS:
        raise ValueError('Refuse symlink/private-directory archive input')
    def inspect_material(value: bytes) -> None:
        if key and key in value:
            raise ValueError('Credential unexpectedly present in selected artifact; do not export')
        # Quoted detector literals are not PEM material. A standalone header or
        # an embedded/escaped header followed by a PEM body remains forbidden.
        # Apply the same checks to decoded JSON strings, without path exemptions.
        if PEM_HEADER.search(value) or PEM_BODY.search(value):
            raise ValueError('Private key material in selected artifact')
    inspect_material(content)
    if path.suffix in {'.json', '.jsonl'}:
        values = [json.loads(line) for line in content.decode().splitlines()] if path.suffix == '.jsonl' else [json.loads(content)]
        def inspect(value):
            if isinstance(value, dict):
                if any(str(name).lower() in {'reasoning_content', 'authorization', 'chain_of_thought'} for name in value):
                    raise ValueError('Private reasoning/header field in selected artifact')
                for child in value.values():
                    inspect(child)
            elif isinstance(value, list):
                for child in value:
                    inspect(child)
            elif isinstance(value, str):
                inspect_material(value.encode())
        for value in values:
            inspect(value)

def collect(paths: list[str]) -> list[Path]:
    files = set()
    for relative in paths:
        path = RUN / relative
        if not path.exists():
            raise ValueError(f'Required evidence artifact missing: {relative}')
        if path.is_dir():
            for candidate in path.rglob('*'):
                if candidate.is_file() and not set(candidate.relative_to(RUN).parts) & DENIED_PARTS:
                    if candidate.name != '.DS_Store':
                        files.add(candidate)
        else:
            files.add(path)
    return sorted(files)

def package(name: str, files: list[Path], output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    archive = output / f'{name}.tar.gz'
    manifest_path = output / f'{name}.manifest.json'
    if archive.exists() or manifest_path.exists():
        raise ValueError('Never overwrite an existing archive/manifest')
    key = KEY.read_bytes().strip()
    payload = []
    for path in files:
        content = path.read_bytes()
        assert_public(path, content, key)
        relative = PurePosixPath('mac-takeover-20261011') / path.relative_to(RUN).as_posix()
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Unsafe archive member')
        payload.append((relative.as_posix(), content))
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
            with tarfile.open(mode='w', fileobj=compressed, format=tarfile.PAX_FORMAT) as tar:
                for relative, content in payload:
                    info = tarfile.TarInfo(relative)
                    info.size, info.mtime, info.mode = len(content), 0, 0o644
                    info.uid = info.gid = 0
                    tar.addfile(info, io.BytesIO(content))
    entries = [{'path': relative, 'bytes': len(content), 'sha256': sha(content)} for relative, content in payload]
    manifest = {'archive': archive.name, 'bytes': archive.stat().st_size,
                'sha256': sha(archive.read_bytes()), 'entries': entries,
                'scope': 'Explicit file allowlist; failed/unknown records retained; no database, dependencies, key, headers or reasoning_content.',
                'deterministic_archive': 'gzip mtime=0; sorted regular members; uid/gid/mtime=0; mode=0644; no symlinks.'}
    with manifest_path.open('x') as stream:
        json.dump(manifest, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    with tarfile.open(archive) as tar:
        actual = []
        for member in tar:
            if not member.isfile() or member.issym() or member.islnk():
                raise ValueError('Unsafe generated archive member')
            content = tar.extractfile(member).read()
            actual.append({'path': member.name, 'bytes': len(content), 'sha256': sha(content)})
        if actual != entries:
            raise ValueError('Generated archive content did not verify')
    print(json.dumps({'archive': str(archive), 'entries': len(entries), 'bytes': manifest['bytes'],
                      'sha256': manifest['sha256'], 'verified': True}), flush=True)
    return manifest

GROUPS = {
    'mac-native-tokenizer': ['native-tokenizer'],
    'mac-restoration-records': ['environment.json', 'replay-verification.json', 'preflight-observed.json',
        'preflight.json', 'provider-probe.json', 'primary-recomputed', 'primary-recomputed-dynamic-tools',
        'primary-replay.log', 'audit-replay.log', 'smoke', 'smoke-provider-max', 'smoke-provider-max-v2',
        'contract-contrib-environment.json', 'restore.py', 'provider_probe.py', 'fetch_sources.py',
        'prepare_contract_contrib.py', 'blingfire-build/CMakeCache.txt'],
    'mac-development-records': ['rfc-development-v1', 'rfc-development-scoped-v2',
        'development-scoped-source-audit-v1.json', 'development-unscoped-source-audit-v1.json'],
    'mac-validation-records': ['api-dns-baseline.xml', 'api-failure-isolation.xml', 'api-sequential.xml',
        'shared-source-v2.xml', 'worker-source-v2.xml', 'benchmark-source-scoped-v3.xml',
        'benchmark-source-scoped-v3-configured.xml', 'local-check-invocation-errors.json',
        'controlled-source-v2.json', 'controlled-source-v2-adapter-fixed.json',
        'independent-code-review.json', 'independent-code-review-guard-followup.json',
        'independent-code-review-guard-followup.started.json', 'independent-code-review-guard-followup.events.jsonl',
        'independent_code_review.py', 'independent_guard_followup.py', 'remote-checks-after-push.json',
        'fork-gitleaks-diagnosis.json', 'fork-gitleaks-history-metadata.json', 'fork-gitleaks-fingerprint-classification.json',
        'github_project_checks.py', 'github_fork_check_diagnosis.py', 'github_fork_history_findings.py',
        'classify_fork_history_findings.py', 'pr-update-in-progress.json', 'PR_BODY_PENDING.md'],
    'mac-heldout-records': ['rfc-heldout-scoped-v3', 'heldout-source-audit.json',
        'host-sleep-observation.json',
        'audit_frozen_results.py', 'finalize_heldout.py', 'heldout_progress.py', 'archive_records.py',
        'finish_evidence_archive.py', 'classify_archive_scan.py'],
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--group', choices=tuple(GROUPS), required=True)
    parser.add_argument('--output', type=Path, default=DOCS)
    args = parser.parse_args()
    if args.group == 'mac-heldout-records':
        audit = json.loads((RUN / 'heldout-source-audit.json').read_text())
        summary = json.loads((RUN / 'rfc-heldout-scoped-v3/summary/summary.json').read_text())
        if not audit['passed'] or audit['recorded'] != 144 or summary['validation']['actual_episodes'] != 144:
            raise ValueError('Do not archive an incomplete/unaudited run as the finalized held-out result')
    package(args.group, collect(GROUPS[args.group]), args.output)
