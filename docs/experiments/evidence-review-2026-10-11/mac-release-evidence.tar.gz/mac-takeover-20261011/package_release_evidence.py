"""Package only post-run, explicitly selected public release evidence once."""
from __future__ import annotations

import hashlib
import json

import archive_records as archive

FILES = [
    'CONTINUATION.md', 'archive-helper-original-failure.log',
    'archive-helper-repair-observation.json', 'archive-repair-checks.json',
    'archive-guard-and-accounting.xml', 'test_archive_records_guard.py',
    'archive_records.py', 'archive-scan-final.json',
    'archive-scan-final-classification.json', 'archive-scan-final-documents.json',
    'archive-scan-final-documents-classification.json', 'evidence-release-observation.json',
    'failed-review-activity-observation.json', 'final-archive-member-verification.json',
    'verify_archive_members.py', 'heldout-report-draft', 'prepare_benefit_report.py',
    'test_prepare_benefit_report.py', 'await_and_prepare_report.py',
    'report-preparation-events.jsonl', 'heldout-source-audit.json',
    'host-sleep-observation.json', 'late-connection-failures-observation.json',
    'late-connection-failure-023-observation.json', 'github_project_checks.py',
    'pr-update-final.json', 'primary-report-review-observation.json',
    'release-documents-push-observation.json', 'final-pr-body-verification.json',
    'package_release_evidence.py',
]


if __name__ == '__main__':
    member_check = json.loads((archive.RUN / 'final-archive-member-verification.json').read_text())
    scan = json.loads((archive.RUN / 'archive-scan-final-documents-classification.json').read_text())
    accounting = json.loads((archive.RUN / 'heldout-report-draft/independent-accounting.json').read_text())
    responses = json.loads((archive.RUN / 'pr-update-final.json').read_text())
    body = (archive.DOCS / 'PR_BODY.md').read_text()
    if (member_check['status'] != 'passed' or len(member_check['archives']) != 5
            or scan['unresolved'] or accounting['status'] != 'independent_accounting_crosscheck_passed'
            or accounting['expected_episodes'] != 144 or len(responses['observations']) != 2):
        raise ValueError('Incomplete final release prerequisites')
    endpoints = {'/repos/Ontos-AI/knowhere/pulls/457', '/repos/xcosmosbox/knowhere/pulls/1'}
    if {row['endpoint'] for row in responses['observations']} != endpoints:
        raise ValueError('Unexpected PR update target')
    for row in responses['observations']:
        if (row['method'] != 'PATCH' or row['http_status'] != 200
                or row['data']['body'] != body or row['data']['merged']
                or row['data']['head']['sha'] != 'd4d32ad74091b4040e1a1e8d7dae10f6a5b222c1'):
            raise ValueError('Final PR response does not verify')
    doc_observation = json.loads((archive.RUN / 'primary-report-review-observation.json').read_text())
    for name, expected in doc_observation['final_documents_sha256'].items():
        if hashlib.sha256((archive.DOCS / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Reviewed document changed before release packaging')
    archive.package('mac-release-evidence', archive.collect(FILES), archive.DOCS)
