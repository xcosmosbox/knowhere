"""Offline adversarial checks for report-only accounting, no model or DB."""
from copy import deepcopy
import unittest

from prepare_benefit_report import difference, distribution, index, literal_coverage, macro, usage, utc_elapsed_ms


def record():
    return {'provider_usage': {'usage_complete': True}, 'provider_calls': [{
        'kind': 'explorer', 'requested_model': 'deepseek-flash', 'returned_model': 'deepseek-flash',
        'max_tokens': 393216, 'thinking': {'type': 'enabled'}, 'reasoning_effort': 'max',
        'transport_timeout': {'connect': None, 'read': None, 'write': None, 'pool': None},
        'started_at': '2026-10-11T05:00:00+00:00', 'ended_at': '2026-10-11T05:00:01+00:00',
        'usage': {'prompt_tokens': 300, 'completion_tokens': 20, 'total_tokens': 320,
                  'prompt_cache_hit_tokens': 100, 'prompt_cache_miss_tokens': 200,
                  'completion_tokens_details': {'reasoning_tokens': 15}}}]}


class AccountingTests(unittest.TestCase):
    def test_complete_dated_usage(self):
        result = usage([record()])
        self.assertTrue(result['usage_complete'])
        self.assertEqual(result['observed_tokens']['total_tokens'], 320)
        self.assertEqual(result['observed_reasoning_tokens'], 15)
        self.assertAlmostEqual(result['complete_dated_estimate_usd'], .0000423)

    def test_missing_usage_is_unknown_not_zero(self):
        row = record()
        row['provider_calls'][0]['usage'] = None
        row['provider_usage']['usage_complete'] = False
        result = usage([row])
        self.assertFalse(result['usage_complete'])
        self.assertIsNone(result['complete_dated_estimate_usd'])
        self.assertEqual(result['unknown_cost_calls'], 1)
        self.assertEqual(result['calls_with_incomplete_usage'], 1)

    def test_cross_date_call_has_unknown_cost(self):
        row = record()
        row['provider_calls'][0]['ended_at'] = '2026-10-12T00:00:01+00:00'
        result = usage([row])
        self.assertTrue(result['usage_complete'])
        self.assertIsNone(result['complete_dated_estimate_usd'])
        self.assertEqual(result['unknown_cost_calls'], 1)

    def test_uncaptured_usage_does_not_become_complete(self):
        row = record()
        row['provider_calls'] = []
        row['provider_usage']['usage_complete'] = False
        result = usage([row])
        self.assertIsNone(result['complete_dated_estimate_usd'])
        self.assertEqual(result['records_with_unknown_usage'], 1)

    def test_inconsistent_cache_is_unknown(self):
        row = record()
        row['provider_calls'][0]['usage']['prompt_cache_hit_tokens'] = 101
        self.assertFalse(usage([row])['usage_complete'])

    def test_missing_returned_model_keeps_cost_unknown(self):
        row = record()
        row['provider_calls'][0].pop('returned_model')
        self.assertIsNone(usage([row])['complete_dated_estimate_usd'])

    def test_wrong_model_is_a_failure(self):
        row = record()
        row['provider_calls'][0]['returned_model'] = 'other'
        with self.assertRaises(AssertionError):
            usage([row])

    def test_transport_limit_is_a_failure(self):
        row = record()
        row['provider_calls'][0]['transport_timeout']['read'] = 30
        with self.assertRaises(AssertionError):
            usage([row])

    def test_role_accounting_retains_failed_record_uncertainty(self):
        row = deepcopy(record())
        row['provider_usage']['usage_complete'] = False
        self.assertIsNone(usage([row], kind='reviewer')['complete_dated_estimate_usd'])

    def test_question_not_episode_weighted(self):
        rows = [{'question_id': 'a', 'value': value} for value in (True, True, True)]
        rows += [{'question_id': 'b', 'value': False}]
        result = macro(rows, 'value')
        self.assertEqual(result['lower'], .5)
        self.assertEqual(result['upper'], .5)

    def test_unknown_has_bounds_not_assigned_zero(self):
        rows = [{'question_id': 'a', 'value': True}, {'question_id': 'a', 'value': None}]
        result = macro(rows, 'value')
        self.assertEqual(result, {'lower': .5, 'upper': 1., 'unknown_episodes': 1})

    def test_duplicate_identity_is_rejected(self):
        with self.assertRaises(AssertionError):
            index([{'id': 'a'}, {'id': 'a'}], 'id')

    def test_difference_uses_percentage_points(self):
        self.assertEqual(difference({'lower': -.01, 'upper': .02}), '-1.00 至 2.00 个百分点')

    def test_literal_quote_requires_original_owner(self):
        packet = {'gold_requirements': [{'proofs': [{'doc_key': 'a', 'chunk_id': 'c', 'quotes': ['exact']}]}],
                  'evidence_items': [{'doc_key': 'b', 'original_chunk_id': 'c', 'text': 'exact'}]}
        self.assertEqual(literal_coverage(packet), 0)
        packet['evidence_items'][0]['doc_key'] = 'a'
        self.assertEqual(literal_coverage(packet), 1)

    def test_missing_fact_cannot_gain_literal_recall(self):
        self.assertEqual(literal_coverage({'gold_requirements': [{'proofs': []}], 'evidence_items': []}), 0)

    def test_empty_interrupted_packet_still_has_literal_metric(self):
        packet = {'gold_requirements': [{'proofs': [{'doc_key': 'a', 'chunk_id': 'c', 'quotes': ['exact']}]}],
                  'evidence_items': []}
        self.assertEqual(literal_coverage(packet), 0)

    def test_utc_elapsed_preserves_sleep_interval(self):
        row = {'started_at': '2026-10-11T04:25:12.754692+00:00',
               'ended_at': '2026-10-11T04:45:57.018413+00:00', 'duration_ms': 324320.003}
        self.assertAlmostEqual(utc_elapsed_ms(row), 1244263.721)
        self.assertGreater(utc_elapsed_ms(row) - row['duration_ms'], 900000)

    def test_unknown_utc_duration_is_not_zero(self):
        self.assertIsNone(utc_elapsed_ms({'started_at': '2026-10-11T04:00:00+00:00', 'ended_at': None}))
        self.assertEqual(distribution([None, 10])['unknown'], 1)
        self.assertEqual(distribution([None, 10])['mean'], 10)


if __name__ == '__main__':
    unittest.main()
