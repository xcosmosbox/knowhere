# Knowhere Mac 真实模型确认实验：收益报告草稿

状态：原始记录与汇总的独立算术核对完成；仍须主 agent 完成来源/归档核对并审阅本草稿，才可作为最终交付。

含未知评分的保守差异范围包含零，本冻结样本不能确认充分交付率净提升。

被测 revision：`6c12e6971cffe900aec98805a78e35d55aca9239`。24 题，全部 144 个冻结 episode；每题先平均重复，再配对两组。模型为 `deepseek-flash`，thinking enabled、reasoning_effort max、max_tokens=393216。无本地 DeepSeek 时间/步骤/金额/输入输出字节限额；两次审查和一次纠正是有限流程。

## 质量与完整分母

| 指标 | baseline | review |
|---|---:|---:|
| 确认充分交付 | 52/72 | 52/72 |
| 交付失败 | 2/72 | 5/72 |
| 语义评分未知 | 2/72 | 7/72 |
| 充分交付状态未知 | 0/72 | 2/72 |
| 充分交付率保守范围 | 72.22% | 72.22% 至 75.00% |
| 语义 requirement coverage 题内宏平均范围 | 79.17% 至 81.94% | 76.39% 至 86.11% |
| literal gold-span recall 题内宏平均范围 | 79.17% | 79.17% |

充分交付配对差异（review−baseline）保守范围：0.00 至 2.78 个百分点。交付失败是未交付充分证据，不自动证明潜在证据语义不足；语义未知不是零或通过。Literal recall 不能代替语义蕴含。

仅可回答题的确认充分交付：baseline 52/60，review 52/60。部分缺失题仍保留在主分母；相关 RFC 文字不能支持不存在的 operational measurement。

## 公开声明与纠正

公开 review 状态：`{"insufficient": 4, "missing": 5, "sufficient": 51, "unverified": 12}`。有效最终公开审查 55/72。

False-sufficient 0/49 个独立可评分充分声明，另有 2 个声明评分未知；false-insufficient 0/4 个独立可评分不足声明，另有 0 个未知。零错误若出现，必须与这些分母和弃判率一起解读。

实际观察到 4 次纠正；公开尝试/纠正计数缺失分别 5/5 个回合，未填成零。记录了 55 个可盲评首次快照，其中初始充分/不足/未知 51/4/0。

在初始独立不足且实际纠正的 4 次中，0 次最终充分，0 次同时改变证据，相关最终未知 0。这不是所有可能纠正机会的独立估计；相同证据的评分翻转可能来自 judge 波动。

unverified 的原始原因：

```json
{
  "Exploration ended before final evidence was verified.": 12
}
```

## 用量、cache、延迟和日期费用

| 角色 | calls | observed total tokens | cached input | uncached input | completion (含 thinking) | 完整费用 USD | 已知日期费用小计 USD | 未知费用 calls |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| baseline retrieval | 539 | 16,328,346 | 2,317,440 | 3,126,692 | 10,884,214 | 未知 | 7.006485 | 2 |
| review retrieval | 705 | 24,279,001 | 4,242,176 | 5,709,284 | 14,327,541 | 未知 | 9.465644 | 5 |
| baseline explorer | 539 | 16,328,346 | 2,317,440 | 3,126,692 | 10,884,214 | 未知 | 7.006485 | 2 |
| review explorer | 644 | 23,232,383 | 4,117,632 | 5,038,033 | 14,076,718 | 未知 | 9.214089 | 5 |
| review reviewer | 61 | 1,046,618 | 124,544 | 671,251 | 250,823 | 未知 | 0.251555 | 0 |
| 独立盲评（含 controls） | 155 | 2,148,709 | 614,396 | 1,399,569 | 134,744 | 0.292625 | 0.292625 | 0 |

用量缺失时表中 observed tokens 只是已知小计，不能假称完整用量。Reasoning token metadata 是 completion 的子集，不能再次计入总量或费用。价格是 UTC 2026-10-11 Sunday 每百万 cached/uncached/output USD 0.003/0.15/0.6 的列表估算，不是账单；跨日期或响应日期未知的 call 费用保持未知。不同角色用量无法从缺失 episode 精确拆分时，整体完整性也保留未知。

任何一组完整费用未知时，不计算完整检索成本增幅或每额外充分回合成本；独立盲评不混入检索开销。

| Arm | latency mean / p50 / p95 (s) | unknown latency |
|---|---:|---:|
| baseline | 716.907 / 279.651 / 2799.529 | 0 |
| review | 966.764 / 294.459 / 3971.227 | 0 |

上表是未改写的原始 `time.perf_counter()` duration。独立计算的 UTC elapsed：

| Arm | UTC mean / p50 / p95 (s) | unknown UTC duration | UTC−recorded 大于 1s 的回合 |
|---|---:|---:|---:|
| baseline | 729.685 / 279.652 / 2799.532 | 0 | 1 |
| review | 992.319 / 294.459 / 3971.231 | 0 | 2 |

主机电源日志：2026-10-11T12:28:11+08:00 因 Clamshell Sleep 睡眠 922 秒，2026-10-11T12:43:33+08:00 DarkWake。三个在途连接失败与此区间重叠，但未记录底层异常，不能证明唯一原因。原计时、失败及分母不剔除；该主机干扰使结果不能作为干净的生产延迟比较。防空闲睡眠断言不能阻止手动合盖，没有修改全局电源配置。

Stops：baseline `{"finished": 56, "no_response": 2, "no_tool_call": 14}`；review `{"finished": 55, "no_response": 5, "no_tool_call": 12}`。no_tool_call 是真实流程终止，不伪造工具调用，不重新标为 token 截断，不重跑到通过。

## 验证与局限

确认盲包去重后共 152 包，另有 3 次新鲜真实语义负控制。独立算术核对验证了完整日程、唯一启动 ID、输入 hash、provider 参数、评分映射、声明分母和题内配对范围；原模型判断和原始结果未修改。来源、精确引用和最终 fingerprint 由单独的 deterministic source audit 核对，不构成语义真值。

Judge 使用新鲜的组别盲化 prompt 和独立冻结 gold，但与 explorer/reviewer 同属 DeepSeek 模型家族；负控制通过不保证全面可靠。JSON/QUIC 仅两个文档族，公开 RFC 可能在预训练中出现；这是实验未见题，不是保证模型未见数据。没有人类全量真值、p-value 或生产总体显著性声明。

与历史运行相比，thinking、资源、lossless spans 和 closed-scope feedback 同时变化，不能把跨轮差异归因于一个因素。本轮两组只有 review_evidence 开关不同，但这只能描述新配置下的组间结果。生产默认限制和 default-off 未更改。

Explorer 每动作重建 fresh system/user prompt，不保留 provider 原生 assistant/tool/reasoning_content 会话；两组共享该架构。真实 full-read receipts 不是充分性 gold，也不强制审查 verdict。实验覆盖真实检索核心和 PGlite，不包含 HTTP 鉴权/计费/上传解析 worker、live Cursor、native PostgreSQL 并发或生产流量。

历史 300 回合、事后敏感性分析、两个开发协议和本次确认分开保存；开发 5/6 对 5/6 不充当留出收益。生产 CI/CodeQL 成功也不证明模型检索质量。最终归档、安全扫描分类、Git 推送及 PR 正文更新须另行核实。
