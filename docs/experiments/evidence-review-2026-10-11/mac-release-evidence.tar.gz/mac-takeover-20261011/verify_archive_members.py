"""Offline all-member integrity and private-material verification; no extraction."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

import archive_records as archive

EXTRA_DENIED = {'contract-tools-venv', 'blingfire-source', 'postgresql-16.2', 'libpq'}


def verify(docs: Path, expected: int) -> dict:
    key = archive.KEY.read_bytes().strip()
    rows = []
    manifests = sorted(docs.glob('mac-*.manifest.json'))
    if len(manifests) != expected:
        raise ValueError('Unexpected archive set')
    for manifest_path in manifests:
        manifest_raw = manifest_path.read_bytes()
        manifest = json.loads(manifest_raw)
        target = docs / manifest['archive']
        if (target.parent != docs or target.is_symlink() or not target.is_file()
                or target.stat().st_size != manifest['bytes']
                or archive.sha(target.read_bytes()) != manifest['sha256']):
            raise ValueError('Archive identity/size/hash verification failed')
        members = []
        names = set()
        with tarfile.open(target) as tar:
            for member in tar:
                name = PurePosixPath(member.name)
                if (not member.isfile() or member.issym() or member.islnk()
                        or name.is_absolute() or '..' in name.parts
                        or not name.parts or name.parts[0] != 'mac-takeover-20261011'
                        or member.name in names or set(name.parts) & EXTRA_DENIED
                        or name.suffix.lower() in {'.db', '.sqlite', '.sqlite3'}):
                    raise ValueError('Unsafe/private archive member')
                names.add(member.name)
                stream = tar.extractfile(member)
                if stream is None:
                    raise ValueError('Missing regular archive payload')
                content = stream.read()
                relative = Path(*name.parts[1:])
                archive.assert_public(archive.RUN / relative, content, key)
                members.append({'path': member.name, 'bytes': len(content), 'sha256': archive.sha(content)})
        if members != manifest['entries']:
            raise ValueError('All-member manifest verification failed')
        rows.append({'archive': target.name, 'manifest': manifest_path.name,
                     'manifest_sha256': hashlib.sha256(manifest_raw).hexdigest(),
                     'sha256': manifest['sha256'], 'bytes': manifest['bytes'],
                     'entries': len(members), 'verified': True,
                     'private_material_checks_passed': True})
    return {'status': 'passed', 'observed_at': datetime.now(timezone.utc).isoformat(),
            'archives': rows, 'total_entries': sum(row['entries'] for row in rows),
            'checks': ['archive size/hash', 'every regular member size/hash and exact manifest order',
                       'unique safe relative paths, no links/devices',
                       'no database/dependency checkout/private directory',
                       'exact existing private credential and PEM material absent',
                       'no protected private-reasoning/header fields in JSON/JSONL'],
            'scope': 'No extraction, model request, source/result mutation, scanner exemption or history change.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--docs', type=Path, default=archive.DOCS)
    parser.add_argument('--expected-archives', type=int, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Never overwrite an existing verification observation')
    result = verify(args.docs, args.expected_archives)
    with args.output.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'archives': len(result['archives']),
                      'total_entries': result['total_entries']}))
