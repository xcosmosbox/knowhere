"""Project-scoped GitHub read/update using the existing Git credential helper.

Never print or persist credentials, request headers or exception strings.
Only the two user-authorized Knowhere repositories are addressed.
"""
import argparse
import hashlib
import json
import os
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import httpx

PRODUCTION = Path('/Users/ottofeng/Desktop/knowhere/production-source-spans')
SHA = 'd4d32ad74091b4040e1a1e8d7dae10f6a5b222c1'
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--pr-body', type=Path)
args = parser.parse_args()
if args.output.exists():
    raise ValueError('Retain old remote observations; use a new output path')
result = {'started_at': datetime.now(timezone.utc).isoformat(), 'feature_revision': SHA,
          'observations': [], 'authority': 'Existing Git credential helper; Knowhere only; no merge, main rewrite or new PR.'}
try:
    credential = subprocess.run(['git', 'credential', 'fill'], cwd=PRODUCTION,
        input='protocol=https\nhost=github.com\npath=xcosmosbox/knowhere.git\n\n',
        env={**os.environ, 'GIT_TERMINAL_PROMPT': '0'}, capture_output=True, text=True, check=True)
    fields = dict(line.split('=', 1) for line in credential.stdout.splitlines() if '=' in line)
    token = fields.get('password')
    if not token:
        raise ValueError('No existing GitHub credential')
    with httpx.Client(base_url='https://api.github.com', headers={
        'Authorization': f'Bearer {token}', 'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28', 'User-Agent': 'knowhere-project-verification'}, timeout=30) as client:
        def request(method, endpoint, payload=None):
            response = client.request(method, endpoint, json=payload)
            record = {'method': method, 'endpoint': endpoint, 'http_status': response.status_code,
                      'rate_remaining': response.headers.get('x-ratelimit-remaining')}
            try:
                record['data'] = response.json()
            except ValueError:
                record['non_json'] = True
            if payload is not None:
                record['payload_sha256'] = hashlib.sha256(json.dumps(payload).encode()).hexdigest()
            result['observations'].append(record)
            return record

        if args.pr_body is not None:
            body = args.pr_body.read_text()
            if re.search(r'https?://|www\.|\]\([^)]*://', body, re.I):
                raise ValueError('External link in PR body')
            request('PATCH', '/repos/Ontos-AI/knowhere/pulls/457', {'body': body})
            request('PATCH', '/repos/xcosmosbox/knowhere/pulls/1', {'body': body})
        else:
            for endpoint in (
                '/repos/Ontos-AI/knowhere/pulls/457',
                f'/repos/Ontos-AI/knowhere/commits/{SHA}/check-runs',
                f'/repos/Ontos-AI/knowhere/commits/{SHA}/status',
                f'/repos/xcosmosbox/knowhere/commits/{SHA}/check-runs',
                f'/repos/xcosmosbox/knowhere/actions/runs?head_sha={SHA}&per_page=10',
            ):
                request('GET', endpoint)
    result['status'] = 'observed'
except Exception as exc:
    result.update(status='unavailable', error_type=type(exc).__name__)
result['ended_at'] = datetime.now(timezone.utc).isoformat()
with args.output.open('x') as stream:
    json.dump(result, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'status': result['status'], 'output': str(args.output),
    'observations': [{'endpoint': item['endpoint'], 'http_status': item['http_status'],
                      'check_runs': [{key: row.get(key) for key in ('name', 'status', 'conclusion')}
                                     for row in item.get('data', {}).get('check_runs', [])]}
                     for item in result['observations']]}))
