# Knowhere ongoing experiment checkpoint

This is an operational checkpoint, not a completed benefit report. Read live process/journal state before acting; earlier counts below are dated observations, not the latest state. No test key is included here.

## 2026-10-11 21:38 UTC completion and offline recovery checkpoint

- Original retrieval is complete: 144/144, 72 per arm, 48 per shard; no active started identities. All original workers, finalizer, archive/report companions and bound caffeinate processes have exited. Original last-worker and finalizer tool sessions returned exit 0. HEAD remains `6c12e6971cffe900aec98805a78e35d55aca9239`.
- Original blind evaluation completed 152 unique packets and three fresh negative controls (155 real calls); all three controls passed. Two `invalid_source_span_range` assessments remain invalid/unknown, never retried. Seven APIConnectionError outcomes remain baseline 2/review 5 with unknown returned usage.
- Original source audit passed: 144 records, 402 current source fingerprints, 61 schema-valid reviewer outputs, zero observed length finishes. The primary agent has read the original RESULTS/summary validation, accounting draft, source audit, controls, invalid reasons and late-failure observations.
- Both arms confirmed 52/72 sufficient delivery. Independent paired bounds are 0 to +2.78 percentage points, containing zero: no confirmed net improvement. Complete retrieval costs remain unknown; observed dated subtotals are baseline USD 7.006484520 and review USD 9.465643728. Separate evaluator estimate USD 0.292624938.
- Original archive and dependent report companions exited 1. The archive guard rejected its own quoted PEM detector literals in `archive_records.py`, before creating the formal heldout archive. `archive-helper-original-failure.log`, `archive-helper-repair-observation.json` and `report-preparation-events.jsonl` preserve this failure; no complete original archiver backup exists. Original source hash and diagnosis are recorded.
- A post-run RUN-only offline guard repair distinguishes detector literals from actual PEM material and checks decoded JSON strings. No GROUPS/path exemptions, scanner allowlist/config/history, frozen sources, gold, scoring, model settings or real requests changed. 18 guard tests plus 18 accounting tests passed; initial unrelated pytest-postgresql/libpq plugin startup failure is summarized separately, not erased. Ruff checks pass.
- Pure offline accounting generated `heldout-report-draft/independent-accounting.json` and `heldout-report-draft/BENEFIT_REPORT.md`, with crosscheck passed. Do not rerun into that exclusive-create directory or restart model/finalizer companions.
- Next: create absent `mac-heldout-records` only, run unchanged recursive scanner and exact historical-source classification, verify all five archives, finalize documents, normal scoped experiment-branch commit/push, update existing PRs through `github_project_checks.py`, then package final supplemental release evidence and normal-push it. Preserve previous immutable archives and all original failures. Scheduling remains active until delivery is verified.

## 2026-10-11 21:46 UTC publication checkpoint

- Five stage archives now exist and passed every-member integrity/private-material checks: 123 entries total, heldout 31. Original four archives unchanged. Recursive scan of final documents/archive set exits 1, 132/132 findings individually verified as exact source SHA-256 at recorded revision, zero unresolved. Raw failures remain failed.
- Primary agent finalized BENEFIT_REPORT, MAC_TAKEOVER, REPRODUCE and no-external-link PR_BODY after reviewing actual controls/unknowns/audits. It clarified that four is only the public correction-counter subtotal; two additional failed episodes entered corrective exploration, with missing public counters and no eligible independent first mapping. Original draft/accounting is untouched.
- San_Check normally committed and pushed `2a98087da9b8a1fd1e63927d17cb5c0374c7611b` to the existing experimental branch; ls-remote matched. Only four experiment documents and five archives/manifests changed; worktree then clean. No source/production/main modification, merge or force push.
- The authorized existing helper updated upstream 457 and fork 1 with the identical final no-link body: both HTTP 200, response bodies exactly match saved PR_BODY, both head at production `d4d32ad74091b4040e1a1e8d7dae10f6a5b222c1`, both still open/unmerged. New response evidence: `pr-update-final.json` and `final-pr-body-verification.json`.
- Remaining: immutable `mac-release-evidence` package with these final PR responses, all-member/private-material verification of six archives, final raw scanner/classification sidecars, RELEASE_VERIFICATION, normal supplemental push and remote SHA check. Then delete the completed heartbeat and deliver file links. Do not restart any model work.

## Current frozen measurement

- Worktree: `/Users/ottofeng/Desktop/knowhere/lab-scope-completion`.
- Branch: `test/xcosmosbox/evidence-review-mac-v3`.
- Runtime HEAD/protocol revision: `6c12e6971cffe900aec98805a78e35d55aca9239`.
- Run root: `/Users/ottofeng/Desktop/knowhere/runs/mac-takeover-20261011-2r2hML`.
- Experiment: `rfc-heldout-scoped-v3`, 24 questions × 3 repeats × 2 arms, full 144 denominator.
- On 2026-10-11 04:59:53 UTC, 45/144 completed, 4 APIConnectionError records retained (2/arm), all runtime gates true. The three shards had 20/10/15 records respectively. Do not infer final quality from current public review statuses.
- The frozen runtime's 402 source fingerprints were rechecked on this continuation and all match. Only documents/untracked archives changed in the worktree; no new commit was made.
- DeepSeek Flash thinking enabled/max, provider output limit 393216, actual HTTP timeouts null, retries zero, no local DeepSeek step/time/input-output-byte/money ceiling. Production default limits are separate and unchanged.

## Live sessions and processes

| Stage | Tool exec session | Primary PID |
|---|---:|---:|
| shard 0 | 60987 | node 28295 / Python 28318 |
| shard 1 | 28710 | node 28296 / Python 28319 |
| shard 2 | 11964 | node 28298 / Python 28321 |
| original finalizer | 28603 | 37456 |
| corrected archive companion | 50368 | 93640 |
| offline report-preparation companion | 72514 | 2050 |
| added AC sleep assertion | 54025 | 8096 |

Confirm PID command identities; do not rely on stale PID values. Original worker-bound caffeinate assertions remain. The added `caffeinate -s -w 37456` is process-scoped, not a global power setting.

The Codex app heartbeat `Knowhere 实验接续`, automation ID `knowhere`, was successfully created ACTIVE for this same chat on a 30-minute cadence, then opened with the view tool successfully. It is a continuation of the existing work, not a new task/worktree or a DeepSeek budget. It should finish primary-agent report/Git/PR work after the existing pipeline, report meaningful progress/errors/completion, and end only once delivery is actually complete or user direction is needed. Local scheduling requires the Mac and desktop app to remain running. Use the app automation tool for changes; never manually edit scheduler TOML.

Use `knowhere/.venv/bin/python RUN/heldout_progress.py --compact` with the absolute RUN path above for current state. Do not launch duplicates or change frozen code/HEAD while retrieval/evaluation is active.

## Automatic stages already running

1. `finalize_heldout.py` waits for all original workers to exit and all 144 records. It verifies HEAD/source/gold, runs the frozen real arm-blind judge with three new semantic negative controls and concurrency four, then summarizes. No model retries or replacement trials.
2. `finish_evidence_archive.py` now waits for the finalizer to exit and checks complete summary/RESULTS/summary.log, 144 episodes, three passed controls and no gate failures. It performs offline source/fingerprint audit, final heldout archive, recursive Gitleaks scan and exact historical-source fingerprint classification. It writes `evidence-release-observation.json` only after these checks. This companion was restarted while still waiting; no retrieval worker/model request was restarted.
3. `await_and_prepare_report.py` waits for that release observation, verifies all members of the five completed-stage archives, saves `final-archive-member-verification.json`, and invokes the independent `prepare_benefit_report.py` into `heldout-report-draft`. It makes no model/Git/PR calls. Failures stop and retain evidence.

The report arithmetic helper passed 18 offline adversarial tests and cross-checked all 12 scoped-development records. Its development output is `report-check-development-v4`, not heldout benefit evidence. It recomputes frozen denominators, blind mapping, independent claim/correction counts, literal ownership, dated/cache/role usage and unknown bounds. Missing public counters in failed episodes stay null, not zero. It reports recorded monotonic and independent UTC durations separately. The report output is a draft until the primary agent reviews it.

## Host-sleep confound

Read `host-sleep-observation.json`. Power logs show clamshell sleep at 12:28:11 +08:00 for 922 seconds, followed by DarkWake at 12:43:33. Three new in-flight failure episodes overlapped it; the earlier failure did not. Temporal overlap is not proof of the sole connection cause; underlying exception and provider billing remain unknown. Their UTC elapsed durations exceed recorded `time.perf_counter()` durations by approximately 920 seconds. Keep original results and both clock measurements. Caffeinate cannot guarantee protection against manual lid closure. Keep Mac open, online and the desktop app running; do not change global power settings.

## Later connection failures and non-convergence observation

Read `late-connection-failures-observation.json` and include it in the separate final supplemental evidence archive. At 2026-10-11 13:33:30 UTC, 126/144 episodes are recorded, with six retained APIConnectionError episodes (baseline 2, review 4), and no gate failures. Shards 0 and 2 have all 48 records; shard 1 continues its original schedule. No runtime/HEAD/model parameters or original processes were changed.

Two additional failures occurred at 13:29 UTC: `rfc-held-020:1:review` and `rfc-held-024:2:review`. No overlapping new sleep event was found, and the two clock durations agree within milliseconds; the underlying network/provider cause and billing remain unknown. Subsequent existing scheduled episodes received HTTP 200 responses; the failed identities were not resent.

The long `rfc-held-024:2:review` ran about 3 hours 20 minutes, made 76 calls, and ended by connection error, not a natural finish. It had fully read all 183 permitted text units and received the source-exhaustion hint from 12:14 UTC onward, but continued repetitive searches/picks after its first review/correction. Request activity did not imply new evidence progress. The source-exhaustion hint is prompt-only, not an enforced runtime stop, so removing local resource ceilings does not guarantee convergence. Preserve this actual behavior and the failed denominator in the final benefit report; do not silently repair/force-finish/retry this frozen run.

After the failure notification, the user directly reported having just switched networks and suggested this may explain the interruption. Record this as a user-reported possible shared transport cause, with no independently verified switch timestamp; do not claim a sole cause or blame model quality for the connection exception. Separately report the preceding long non-convergence/repetitive correction as an observed system-level usability/termination failure. This does not retroactively introduce a three-hour cutoff or alter the frozen outcome; finite-time non-convergence is not proof that natural completion was impossible. Do not isolate the effect of thinking/model/reviewer from this multi-factor workflow observation.

## Subsequent original-schedule connection failure

At 2026-10-11 13:52:12 UTC, live read-only checks found 127/144 recorded episodes (baseline 63, review 64), seven retained APIConnectionError episodes (baseline 2, review 5), and no gate failures. Read `late-connection-failure-023-observation.json` and include it alongside the prior late-failure observation in the separate final supplemental archive.

The additional original-schedule failure is `rfc-held-023:1:review`, from 13:29:54 to 13:46:29 UTC. Ten of eleven requests returned HTTP 200, including a reviewer response at 13:42:22; the next explorer request has no returned status or usage. Its two duration measures agree within milliseconds, and no new overlapping sleep was found. The user-reported network switch remains a possible environmental/transport cause, with no verified timestamp or sole attribution. This episode's roughly 16.6-minute failure must not be conflated with the separately observed 3-hour-20-minute non-convergence of `rfc-held-024:2:review`.

The original shard 1 worker continues `rfc-held-023:1:baseline`; shards 0 and 2 have all 48 records each. Original finalizer/archive/report process identities remain live and waiting. Blind evaluation has not begun. HEAD remains `6c12e6971cffe900aec98805a78e35d55aca9239`; no frozen source/config/process, scoring, Git, or model-request mutation was performed. Do not resend the failed ID or turn incomplete provider usage into a complete cost.

## Production and documentation

- Separate production worktree `/Users/ottofeng/Desktop/knowhere/production-source-spans` is clean at `d4d32ad74091b4040e1a1e8d7dae10f6a5b222c1`; the existing feature branch already has it remotely. Experiment branch remote is 6c12. Both were rechecked via ls-remote.
- Exact-head upstream Test/Lint/Typecheck/Analyze/CodeQL/Gitleaks success. Fork first five success, current-tree scan pass, all-refs history Gitleaks failed on 66 verified source-hash fields from unrelated historical experiment commits. Scanner failure stays failed; no allowlist/history changes.
- Both existing PRs already received self-contained, no-external-link in-progress bodies successfully. No new PR, merge or force push.
- Repository MAC_TAKEOVER/PR_BODY were corrected for completed CI; MAC_TAKEOVER/REPRODUCE document the host sleep. These document edits remain uncommitted to preserve frozen HEAD.
- Four immutable completed-stage archives (92 entries total) are already present; never overwrite them. Formal heldout archive is not present until the pipeline completes.

## Required final work after all stages complete

Review original summary and independent accounting/source audits, controls, unknowns, false sufficient/insufficient denominators, actual corrections and evidence changes. Preserve all 72 scheduled episodes/arm, including failures. Semantic facet coverage and literal recall differ. Unknown total cost cannot be replaced by known subtotal or used to compute a complete overhead percentage. Report UTC clock/sleep confounding, same-family judge, two public RFC families/pretraining exposure, fresh-prompt rather than native thinking conversation, and multi-factor changes versus history. No p-values, population claims or attribution to thinking/spans alone.

Finalize BENEFIT_REPORT/MAC/REPRO/PR documents from actual completed data. Package a separate supplemental release-evidence archive for final scan classifications, member verification, report arithmetic/tools/tests and final PR update metadata; do not rewrite earlier archives. Verify every member, no key/DB/dependencies/private reasoning, and retain raw scanner exit/findings plus classification. Run diff checks. Only after retrieval/evaluation/finalizer have actually exited may documentation/archive commits change HEAD. Commit only intended experiment documents/archives as San_Check with the existing noreply email and no coauthor, then normal push to the existing experiment branch. Use the existing GitHub helper for the two existing no-link PR bodies, saving a new response artifact. Do not merge or modify main/production history. Report actual outcome; no net gain is allowed.
