"""Offline export-guard regression tests; all sensitive samples are synthetic."""
import json

import pytest

import archive_records as archive

FAKE_KEY = b'unit-test-only-not-a-real-provider-credential'


def header(kind=''):
    return b'-----BEGIN ' + kind.encode() + b'PRIVATE KEY-----'


@pytest.mark.parametrize('kind', ['', 'RSA ', 'EC ', 'ENCRYPTED ', 'OPENSSH '])
def test_standalone_pem_header_is_denied(kind):
    with pytest.raises(ValueError, match='Private key material'):
        archive.assert_public(archive.RUN / 'synthetic.txt', header(kind) + b'\n' + b'A' * 64, FAKE_KEY)


@pytest.mark.parametrize('newline', [b'\n', b'\\n', b'\\r\\n'])
def test_embedded_or_escaped_pem_body_is_denied(newline):
    content = b'value = "' + header('RSA ') + newline + b'A' * 64 + b'"'
    with pytest.raises(ValueError, match='Private key material'):
        archive.assert_public(archive.RUN / 'synthetic.py', content, FAKE_KEY)


def test_decoded_nested_json_pem_is_denied():
    content = json.dumps({'nested': [{'value': (header('EC ') + b'\n').decode()}]}).encode()
    with pytest.raises(ValueError, match='Private key material'):
        archive.assert_public(archive.RUN / 'synthetic.json', content, FAKE_KEY)


def test_decoded_json_credential_is_denied():
    escaped = b'{"value":"' + b''.join(('\\u%04x' % char).encode() for char in FAKE_KEY) + b'"}'
    with pytest.raises(ValueError, match='Credential unexpectedly present'):
        archive.assert_public(archive.RUN / 'synthetic.json', escaped, FAKE_KEY)


def test_exact_credential_is_denied():
    with pytest.raises(ValueError, match='Credential unexpectedly present'):
        archive.assert_public(archive.RUN / 'synthetic.txt', b'prefix ' + FAKE_KEY, FAKE_KEY)


@pytest.mark.parametrize('field', ['reasoning' + '_content', 'author' + 'ization', 'chain_of' + '_thought'])
def test_protected_nested_json_field_is_denied(field):
    with pytest.raises(ValueError, match='Private reasoning/header field'):
        archive.assert_public(archive.RUN / 'synthetic.json', json.dumps({'nested': [{field: 'synthetic'}]}).encode(), FAKE_KEY)


def test_private_directory_is_denied():
    with pytest.raises(ValueError, match='private-directory'):
        archive.assert_public(archive.RUN / 'db-1' / 'synthetic.txt', b'not sensitive', FAKE_KEY)


def test_quoted_detector_literals_are_not_pem_material():
    content = b'if b\'' + header() + b'\' in content or b\'' + header('RSA ') + b'\' in content:\n    raise ValueError()\n'
    archive.assert_public(archive.RUN / 'synthetic.py', content, FAKE_KEY)


def test_archiver_self_inspection_without_path_exemption():
    path = archive.RUN / 'archive_records.py'
    archive.assert_public(path, path.read_bytes(), FAKE_KEY)


def test_safe_json_and_jsonl_are_allowed():
    safe = json.dumps({'status': 'valid', 'usage': {'total_tokens': 10}}).encode()
    archive.assert_public(archive.RUN / 'synthetic.json', safe, FAKE_KEY)
    archive.assert_public(archive.RUN / 'synthetic.jsonl', safe + b'\n' + safe + b'\n', FAKE_KEY)
