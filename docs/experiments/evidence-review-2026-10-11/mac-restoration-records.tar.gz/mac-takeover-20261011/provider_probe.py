"""One capability probe, distinct from retained retrieval outcomes."""
import json
from pathlib import Path
from openai import OpenAI, BadRequestError

key = Path('/Users/ottofeng/.config/knowhere/deepseek-test.key').read_text().strip()
client = OpenAI(api_key=key, base_url='https://api.deepseek.com/v1', timeout=None, max_retries=0)
try:
    response = client.chat.completions.create(model='deepseek-flash', max_tokens=393216,
        reasoning_effort='max', extra_body={'thinking': {'type': 'enabled'}},
        messages=[{'role':'user','content':'Pick R1.1 by calling the supplied tool.'}],
        tools=[{'type':'function','function':{'name':'corpus_pick','parameters':{
            'type':'object','properties':{'pick':{'type':'array','items':{'type':'string'}}},
            'required':['pick'],'additionalProperties':False}}}],
        tool_choice={'type':'function','function':{'name':'corpus_pick'}})
    result = {'status':'success','model':response.model,'usage':response.usage.model_dump()}
except BadRequestError as exc:
    result = {'status':'provider_rejected', 'http_status':exc.status_code,
              'body':json.loads(json.dumps(exc.body).replace(key, '[redacted]'))}
Path(__file__).with_name('provider-probe.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
