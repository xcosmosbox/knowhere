"""Add exact-version contrib modules to isolated PostgreSQL, never system-wide."""
import hashlib
import json
import subprocess
import tarfile
import urllib.request
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).parent
PREFIX = ROOT / 'contract-tools-venv/lib/python3.12/site-packages/pgserver/pginstall'
ARCHIVE = ROOT / 'postgresql-16.2.tar.bz2'
URL = 'https://ftp.postgresql.org/pub/source/v16.2/postgresql-16.2.tar.bz2'
if not ARCHIVE.exists():
    urllib.request.urlretrieve(URL, ARCHIVE)
actual = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
expected = urllib.request.urlopen(URL + '.sha256').read().decode().split()[0]
assert actual == expected, (actual, expected)
source = ROOT / 'postgresql-16.2'
if not source.exists():
    with tarfile.open(ARCHIVE) as archive:
        for member in archive.getmembers():
            parts = PurePosixPath(member.name)
            assert not parts.is_absolute() and '..' not in parts.parts
        archive.extractall(ROOT, filter='data')
pg_config = PREFIX / 'bin/pg_config'
sdk = subprocess.check_output(['xcrun', '--sdk', 'macosx', '--show-sdk-path'], text=True).strip()
for module in ('pg_trgm', 'uuid-ossp'):
    flags = [f'PG_CONFIG={pg_config}', 'USE_PGXS=1', f'PG_SYSROOT={sdk}']
    if module == 'uuid-ossp':
        # Darwin's libc implements the e2fs-compatible uuid.h API. The shipped
        # server was built without uuid support; only this contrib module needs
        # the platform flag. No server source or application code is changed.
        flags.append('PG_CPPFLAGS=-DHAVE_UUID_E2FS -DHAVE_UUID_UUID_H')
    subprocess.run(['make', '-j2', *flags], cwd=source / 'contrib' / module, check=True)
    subprocess.run(['make', 'install', *flags], cwd=source / 'contrib' / module, check=True)
report = {'postgres_version': '16.2', 'source_url': URL, 'source_sha256': actual,
          'modules': ['pg_trgm', 'uuid-ossp'], 'prefix': str(PREFIX), 'scope': 'Isolated contract tools only; benchmark PGlite and locked application venv unchanged.'}
(ROOT / 'contract-contrib-environment.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
