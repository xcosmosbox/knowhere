"""Keep complete, immutable official RFC source documents; never select by gold."""
import hashlib
import json
from pathlib import Path
from urllib.request import urlopen

target = Path(__file__).resolve().parent / 'new-source-documents'
target.mkdir()
records = []
for number in [2119, 8259, 7493, 9000, 9001]:
    url = f'https://www.rfc-editor.org/rfc/rfc{number}.txt'
    with urlopen(url) as response:
        raw = response.read()
    path = target / f'rfc{number}.txt'
    path.write_bytes(raw)
    records.append({'rfc': number, 'url': url, 'bytes': len(raw),
                    'sha256': hashlib.sha256(raw).hexdigest(), 'selection': 'complete original source'})
(target / 'manifest.json').write_text(json.dumps(records, indent=2) + '\n')
print(json.dumps(records))
