"""Auditable Mac takeover checks. Historical evidence is copied, never modified."""
import argparse
import asyncio
import copy
import hashlib
import importlib.metadata
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path('/Users/ottofeng/Desktop/knowhere/knowhere')
SOURCE = ROOT / 'docs/experiments/evidence-review-2026-10-10'
OUTPUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'scripts/evidence_review_benchmark'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (OUTPUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def execute(name, command):
    result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
    (OUTPUT / f'{name}.log').write_text(result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError(f'{name} failed: inspect saved log; exit {result.returncode}')
    return {'command': command, 'exit_code': result.returncode, 'log_sha256': sha(OUTPUT / f'{name}.log')}


def replay():
    target = OUTPUT / 'records'
    shutil.copytree(SOURCE, target)
    archives = []
    for name in ['calibration-development-records', 'heldout-traces',
                 'heldout-assessments', 'audit-records', 'corpus-records']:
        manifest = json.loads((target / f'{name}.manifest.json').read_text())
        archive = target / manifest['archive']
        assert archive.stat().st_size == manifest['bytes']
        assert sha(archive) == manifest['sha256']
        with tarfile.open(archive) as tar:
            for member in tar.getmembers():
                parts = PurePosixPath(member.name)
                assert not parts.is_absolute() and '..' not in parts.parts
                assert not member.issym() and not member.islnk()
            tar.extractall(target, filter='data')
        for item in manifest['entries']:
            path = target / item['path']
            assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256']
        archives.append({'name': name, 'entries': len(manifest['entries']), 'sha256': sha(archive)})
    protocol = json.loads((target / 'protocol-reproduction-v2.json').read_text())
    mismatches = [path for path, expected in protocol['runtime_source_sha256'].items()
                  if sha(ROOT / path) != expected]
    assert not mismatches, mismatches
    commands = [execute('primary-replay', [sys.executable, 'scripts/evidence_review_benchmark/summarize.py',
                '--trials', *[str(target / f'heldout/shard-{shard}/trials.jsonl') for shard in range(7)],
                '--assessments', str(target / 'heldout-evaluation'), '--output', str(OUTPUT / 'primary-recomputed')]),
                execute('audit-replay', [sys.executable, 'scripts/evidence_review_benchmark/audit_summary.py',
                                       '--base', str(target)])]
    original = json.loads((SOURCE / 'heldout-results/summary.json').read_text())
    recomputed = json.loads((OUTPUT / 'primary-recomputed/summary.json').read_text())
    def portable(value):
        value = copy.deepcopy(value)
        inputs = value['validation']['input_sha256']
        value['validation']['input_sha256'] = sorted(inputs.values())
        return value
    assert portable(original) == portable(recomputed), 'Primary metrics changed'
    audit = json.loads((target / 'audit-sensitivity.json').read_text())
    assert audit == json.loads((SOURCE / 'audit-sensitivity.json').read_text()), 'Audit metrics changed'
    report = {'restored_revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'archives': archives, 'entries': sum(a['entries'] for a in archives),
              'source_fingerprints_verified': len(protocol['runtime_source_sha256']),
              'primary_equal_except_input_paths': True, 'sensitivity_equal': True,
              'trials': len(recomputed['case_audit']),
              'sensitivity': audit['sensitivity_modes'], 'commands': commands}
    save('replay-verification.json', report)
    print(json.dumps({k: report[k] for k in ['entries', 'source_fingerprints_verified', 'trials',
                                           'primary_equal_except_input_paths', 'sensitivity_equal']}))


def environment():
    versions = {name: importlib.metadata.version(name) for name in
                ['openai', 'httpx', 'asyncpg', 'SQLAlchemy', 'psycopg2-binary', 'numpy', 'alembic']}
    report = {'os': platform.platform(), 'machine': platform.machine(), 'python': platform.python_version(),
              'node': subprocess.check_output(['node', '--version'], text=True).strip(),
              'uv': subprocess.check_output(['uv', '--version'], text=True).strip(), 'libraries': versions}
    save('environment.json', report)
    print(json.dumps(report))


def preflight():
    from runtime import prepare_environment
    assert os.environ.get('DATABASE_URL', '').startswith('postgresql+asyncpg://postgres@127.0.0.1:'), 'Use PGlite launcher'
    prepare_environment()
    from corpus import migrate_database, prepare_corpus, seed_corpus
    manifest = prepare_corpus(ROOT, ROOT / 'scripts/fixtures/evidence_review_live_gold.json')
    migrations = migrate_database(ROOT)
    index = asyncio.run(seed_corpus(manifest))
    save('preflight-observed.json', {'migrations': migrations, 'index': index})
    assert index['status'] == 'verified'
    assert (index['chunk_count'], index['map_unit_count'], index['token_row_count']) == (765, 765, 123307)
    historical = json.loads((OUTPUT / 'records/heldout/shard-0/index-verification.json').read_text())
    assert index == historical, 'Published corpus/index differs from historical experiment'
    save('preflight.json', {'migrations': migrations, 'index': index, 'matches_historical_index': True})
    print(json.dumps({'status': 'verified', 'chunks': index['chunk_count'],
                      'map_units': index['map_unit_count'], 'token_rows': index['token_row_count']}))


def smoke():
    trials = [json.loads(line) for line in (OUTPUT / 'smoke/development/trials.jsonl').read_text().splitlines()]
    assert {t['id'] for t in trials} == {'dev-001:0:baseline', 'dev-001:0:review'}
    for trial in trials:
        assert trial['error'] is None and all(trial['gates'].values())
        assert trial['provider_usage']['usage_complete']
        assert trial['provider_usage']['returned_models'] == ['deepseek-flash']
        assert trial['response']['router_used'] == 'agent_explore'
    report = [{'id': t['id'], 'usage': t['provider_usage'], 'gates': t['gates'],
               'status': (t['response'].get('evidence_review') or {}).get('status'),
               'duration_ms': t['duration_ms']} for t in trials]
    save('smoke-verification.json', report)
    print(json.dumps(report))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['replay', 'environment', 'preflight', 'smoke'])
    mode = parser.parse_args().mode
    globals()[mode]()
