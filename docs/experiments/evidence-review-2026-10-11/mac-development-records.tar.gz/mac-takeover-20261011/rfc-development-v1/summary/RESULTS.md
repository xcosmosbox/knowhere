# Frozen development evidence-review results

Descriptive results for 6 frozen development questions, 1 repeats and two arms (12 episodes). Repeats are averaged within questions. There are 1 document families; no population significance claim or p-value is made.

| Stratum | Baseline confirmed sufficient | Review confirmed sufficient | Paired sufficiency delta (percentage points) | Paired semantic coverage delta (percentage points) |
|---|---:|---:|---:|---:|
| All development | 5/6 | 5/6 | 0.000 | 0.000 |
| bcp14 | 5/6 | 5/6 | 0.000 | 0.000 |

Confirmed counts are lower bounds if semantic scores are unknown. Delivery failures remain in the scheduled denominator; unknown assessments are reported separately and are not treated as definite semantic failures.

| Arm | Answerable sufficient | Unknown semantic scores | Delivery errors | Latency p50/p95 (s) | Observed real tokens | Complete usage | Estimated USD |
|---|---:|---:|---:|---:|---:|---|---:|
| baseline | 5/5 | 0 | 0 | 24.617/1,056.620 | 522,400 | true | 0.193 |
| review | 5/5 | 0 | 0 | 37.398/1,575.972 | 746,419 | true | 0.284 |

Review made 5 sufficient claims: 0 independently false among 5 scored claims, with 0 unverified claims. False-insufficient decisions: 0 among 5 independently sufficient delivered packets.

Observed first-to-final sufficiency flips: 0 among 1 recorded initially insufficient first finishes. Among 1 actual correction attempts, 0 became sufficient, including 0 with changed evidence. This is not an independent budget-eligibility estimate; 0 unchanged-evidence flips may reflect evaluator variability. Initial unknown scores: 0; relevant final unknown scores: 0. Incremental estimated USD per additional sufficient delivery: unknown.

Offline semantic evaluation is separate: 17 real provider calls, estimated USD 0.011; none of this cost is added to retrieval overhead. All three explicit semantic negative controls passed.

Costs are list-rate estimates, not bills. The separately versioned 2026-10-11 UTC price record (Sunday, all-day off-peak) applies only to matching dated calls. Missing usage or other dates leave the total cost unknown. Offline scoring is separate.

The corpus mechanically covers the full frozen source documents; it is not selected by gold answers. Both arms receive the same known document scope. This tests the production retrieval core on PGlite, not visual parsing, HTTP workers, native PostgreSQL concurrency or production traffic. The separate blind judge shares the DeepSeek model family, so correlated errors remain possible. Literal span recall is not semantic correctness; normative text is not a production-traffic sample.

Both arms use the frozen resource intervention: Explicit experimental resource intervention; not production defaults or historical 15-step results. null means no local limit. Natural finish/error/cancellation ends an episode; failed or invalid calls are not retried. This is not directly comparable with historical 15-step/non-thinking results. Development and infrastructure failures are retained separately from held-out benefit metrics.
