# Exact Mac arm64 tokenizer artifact

This is the actual BlingFire library used by the Mac runs, not a substitute tokenizer or a dependency upgrade. The locked Python package remains BlingFire 0.1.8. Its bundled x86_64 library was preserved outside the application environment before the arm64 replacement.

- Source repository: Microsoft BlingFire.
- Source revision: `d9d5cea9cb7f5abbe650ef348c4010dce0658043` (the locked v0.1.8 source).
- Build host: macOS 26.2, Apple Silicon arm64, Apple Command Line Tools C++ compiler.
- CMake configuration: Release, `CMAKE_OSX_ARCHITECTURES=arm64`, Unix Makefiles. The original CMake cache is in the restoration archive.
- Installed and archived library SHA-256: `86444de096909758773cf48561b74bdeec1806d68d08bf228e25303419aa24d9`.
- The Microsoft MIT license is included verbatim.

The historical corpus re-publication with this library matched all original index fields: 765 chunks/map units and 123,307 lexical token rows. The new complete RFC corpus has 200 chunks/map units and 37,274 token rows. Each frozen protocol records this binary hash as part of tokenizer identity.

For exact local protocol replay, verify the archive manifest and installed library hash before running. Preserve any current library before copying this artifact into an isolated arm64 benchmark venv; do not install it into a system Python, Intel environment or production image. Do not modify a frozen protocol to accept a different binary.

A fresh build can be made from the same source with:

```text
cmake -S BLINGFIRE_SOURCE -B BLINGFIRE_BUILD -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES=arm64
cmake --build BLINGFIRE_BUILD
```

Compiler/toolchain/path changes may produce a different Mach-O hash. In that case verify numerical corpus/index equivalence and freeze a new reproduction protocol that records the actual environment; do not present it as a byte-identical replay of the old protocol or a new unseen confirmation dataset.
